<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'myGame';

$connect = new mysqli($servername, $username, $password, $dbname);
if($connect->connect_error){
    die("Ошибка: " . $connect->connect_error);
}
