const sidebar = document.getElementById('sidebar');
sidebar.style.minHeight = `calc(100vh - ${heightHeader})`;