function getCollectionIdByUrl () {
    let url = window.location.href;
    url = url.split("/");
    return url[5];
}

function echoAlertBootstrapRed(str) {
    const mainContainer = document.getElementById('main-container')
    let alertBootstrapRed = document.createElement('div');
    mainContainer.appendChild(alertBootstrapRed);
    alertBootstrapRed.classList.add('alert');
    alertBootstrapRed.classList.add('alert-danger');
    alertBootstrapRed.role = 'alert';
    alertBootstrapRed.id = 'alert-bootstrap-red';
    alertBootstrapRed.innerText = str;
}

async function ajaxRequest(url, params = '', method = 'POST') {
    try {
        const response = await fetch('/ajax/' + url + '.php', {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(params)
        });
        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Fetch error:', error);
    }
}
