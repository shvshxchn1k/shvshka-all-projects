// Состояние
let currentIndex = 0;
let isFlipped = false;

// DOM элементы
const flipCard = document.getElementById('flipCard');
const cardFront = document.getElementById('cardFront');
const cardBack = document.getElementById('cardBack');
const cardCounter = document.getElementById('cardCounter');
const progressDots = document.getElementById('progressDots');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');

// Инициализация
function init() {
    createProgressDots();
    updateCard();
    setupEventListeners();
}

// Создание точек прогресса
function createProgressDots() {
    progressDots.innerHTML = '';
    CARDS.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.className = 'dot';
        if (index === currentIndex) {
            dot.classList.add('active');
        }
        progressDots.appendChild(dot);
    });
}

// Обновление карточки
function updateCard() {
    const card = CARDS[currentIndex];
    cardFront.textContent = card.name;
    cardBack.textContent = card.meaning;
    cardCounter.textContent = `Карточка ${currentIndex + 1} из ${CARDS.length}`;
    
    // Обновление точек прогресса
    document.querySelectorAll('.dot').forEach((dot, index) => {
        if (index === currentIndex) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
    
    // Сброс переворота при переключении
    isFlipped = false;
    flipCard.classList.remove('flipped');
}

// Переворот карточки
function toggleFlip() {
    isFlipped = !isFlipped;
    if (isFlipped) {
        flipCard.classList.add('flipped');
    } else {
        flipCard.classList.remove('flipped');
    }
}

// Переход к предыдущей карточке
function goToPrevious() {
    currentIndex = currentIndex === 0 ? CARDS.length - 1 : currentIndex - 1;
    updateCard();
}

// Переход к следующей карточке
function goToNext() {
    currentIndex = currentIndex === CARDS.length - 1 ? 0 : currentIndex + 1;
    updateCard();
}

// Установка обработчиков событий
function setupEventListeners() {
    flipCard.addEventListener('click', toggleFlip);
    prevBtn.addEventListener('click', goToPrevious);
    nextBtn.addEventListener('click', goToNext);
    
    // Клавиатурная навигация
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            goToPrevious();
        } else if (e.key === 'ArrowRight') {
            goToNext();
        }
    });
}

// Запуск приложения
init();
