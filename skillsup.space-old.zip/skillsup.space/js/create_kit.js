import '/js/functions.js';
const cardCreate = document.getElementById('card-create');
const cardDelete = document.getElementById('card-delete');
const cardTable = document.getElementById('card-table');
let cards;
let lastCard;
let inputNewCardInputWord;
let inputNewCardInputMeaning;
let newCardRow;
let newCardId;
let newCardInputWord;
let newCardInputMeaning;
let i = 5;


cardCreate.addEventListener('click', (e) => {
    i++;
    if (i < 26) {
        if (document.getElementById('alert-bootstrap-red')) {
            document.getElementById('alert-bootstrap-red').remove();
        }
        newCardRow = document.createElement('tr');
        newCardId = document.createElement('th');
        newCardInputWord = document.createElement('td');
        newCardInputMeaning = document.createElement('td');

        cardTable.appendChild(newCardRow);
        //Работаем с newCardId
        newCardRow.appendChild(newCardId);
        newCardId.scope = 'row';
        newCardId.textContent = i;

        // Работаем с newCardInputWord
        newCardRow.appendChild(newCardInputWord);
        inputNewCardInputWord = document.createElement('input');
        newCardInputWord.appendChild(inputNewCardInputWord);
        inputNewCardInputWord.classList.add('form-control');
        inputNewCardInputWord.placeholder = 'Слово';
        inputNewCardInputWord.name = 'word[' + i + '][name]';
        inputNewCardInputWord.required = true;
        inputNewCardInputWord.type = 'text';


        // Работаем с newCardInputMeaning
        newCardRow.appendChild(newCardInputMeaning);
        inputNewCardInputMeaning = document.createElement('input');
        newCardInputMeaning.appendChild(inputNewCardInputMeaning);
        inputNewCardInputMeaning.classList.add('form-control');
        inputNewCardInputMeaning.placeholder = 'Значение/Перевод слова';
        inputNewCardInputMeaning.name = 'word[' + i + '][meaning]';
        inputNewCardInputMeaning.required = true;
        inputNewCardInputMeaning.type = 'text';
    } else {
        if (document.getElementById('alert-bootstrap-red')) {
            document.getElementById('alert-bootstrap-red').remove();
        }
        echoAlertBootstrapRed('В набор нельзя добавить больше 25 карточек');
    }
});

cardDelete.addEventListener('click', (e) => {
    cards = document.querySelectorAll('tr');
    if (cards.length > 6) {
        lastCard = cards[cards.length - 1]; 
        lastCard.remove();
        if (i > 6) {
            i--;
        } 
    } else {
        if (document.getElementById('alert-bootstrap-red')) {
            document.getElementById('alert-bootstrap-red').remove();
        } 
        echoAlertBootstrapRed('Вы не можете удалить больше карточек');
    }
});