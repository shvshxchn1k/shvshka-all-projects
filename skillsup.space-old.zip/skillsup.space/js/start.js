// Файл для проверки команд, которые заходят в игру
import '/js/functions.js';
const list = document.getElementById('list');
const buttonLink = document.querySelectorAll('.disabled-link')[0];
const idRoom = getCollectionIdByUrl();
const params = {id_room: idRoom};
let listItem;
const intervalId = setInterval(() => {
    ajaxRequest('room/start', params).then(checkedTeams => {
        list.textContent = '';
        if (checkedTeams.length === undefined) {
            checkedTeams = Array(checkedTeams);
        }
        if (checkedTeams.length > 1) {
            buttonLink.classList.remove('disabled-link');
        }
        checkedTeams.forEach(checkedTeam => {
            listItem = document.createElement('li');
            list.appendChild(listItem);
            listItem.textContent = checkedTeam.name;
            listItem.id = 'list-item[' + checkedTeam.id + ']';
        });
    });
}, 1000);
