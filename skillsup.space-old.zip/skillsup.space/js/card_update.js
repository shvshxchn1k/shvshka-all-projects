import '/js/functions.js';
const blocker = document.getElementById('blocker');
const buttonSettings = document.getElementById('settings-button');
const deleteButtons = document.querySelectorAll('.btn-delete-card');
const settingsWindow = document.getElementById('settings-window');
const buttonPrivacy = document.getElementById('button-privacy');
let idButton;
let inputs;
let jsonIdButton;
let jsonId;
deleteButtons.forEach(deleteButton => {
    deleteButton.addEventListener('click', (e) => {
        idButton = deleteButton.id.split('-')[1];
        jsonIdButton = {card_id: idButton}
        ajaxRequest('kit/check_quantity_card', jsonIdButton).then(answer => {
            if (answer) {
                ajaxRequest('kit/update_card_status', jsonIdButton).then(answer => {
                    inputs = document.querySelectorAll('#row-' + idButton + ' input[type="text"]');
                    if (typeof answer === 'string') {
                        if (answer === '0') {
                            inputs.forEach(input => {
                                input.disabled = true;
                            });
                            deleteButton.textContent = 'Восстановить';
                            deleteButton.classList.remove('btn-danger');
                            deleteButton.classList.add('btn-primary');
                        } else if (answer === '1') {
                            inputs.forEach(input => {
                                input.disabled = false;
                            });
                            deleteButton.textContent = 'Удалить';
                            deleteButton.classList.remove('btn-primary');
                            deleteButton.classList.add('btn-danger');
                        }
                    }
                });
            } else {
                if (document.getElementById('alert-bootstrap-red')) {
                    document.getElementById('alert-bootstrap-red').remove();
                }
                echoAlertBootstrapRed('В наборе не может быть меньше 5 карточек');
            }
        });
    });
});
buttonSettings.addEventListener('click', (e) => {
    blocker.style.display = 'block';
    blocker.classList.add('d-flex');
});
blocker.addEventListener('click', (e) => {
    blocker.classList.remove('d-flex');
    blocker.style.display = 'none';
});
settingsWindow.addEventListener('click', (e) => {
    e.stopPropagation();
});
buttonPrivacy.addEventListener('click', (e) => {
    jsonId = {
        id: getCollectionIdByUrl(),
    };
    ajaxRequest('kit/update_privacy', jsonId).then(answer => {
        if (answer) {
            if (buttonPrivacy.textContent == 'Только вам') {
                buttonPrivacy.textContent = 'Всем';
            } else {
                buttonPrivacy.textContent = 'Только вам';
            }
        }
    })
});