import '/js/functions.js';
const idRoom = getCollectionIdByUrl();
const activeTeamClasses = ['active-team', 'text-success'];
const modalWindow = document.getElementById('modal-window');
const buttonsWithQuestion = document.querySelectorAll('.btn-with-question');
const questionNameArea = document.getElementById('question-name');
const answeringTeamArea = document.getElementById('answering-team');
const buttonsAnswer = document.querySelectorAll('.button-answer');
let activeTeamCol;
let activeTeam;
let idQuestion;
let params;
let answerOptions;
let answerOption;
let answerOptionId;

const intervalId = setInterval(() => {
    // Делаем запрос на активную команду
    ajaxRequest('room/check_active_team', {id_room: idRoom}).then(activeTeamAnswer => {
        // Делаем проверку на получение ответа
        activeTeam = activeTeamAnswer;
        if (activeTeam.play_status === '1') {
            // Получаем столбик с данными активной команды
            activeTeamCol = document.querySelectorAll('.active-team')[0];
            // Убираем у предыдущего столбика класс активной команды
            activeTeamCol.classList.remove(...activeTeamClasses);
            // Находим новый столбик активной команды
            activeTeamCol = document.getElementById('team[' + activeTeam.id + ']');
            // Добавляем ему классы
            activeTeamCol.classList.add(...activeTeamClasses);
            // Делаем проверку на совпадение активной команды и активной сессии
            if (activeTeam.session) {
                // Если они совпали делаем возможностьь пользователю наживать на кнопки с выбором вопроса
                buttonsWithQuestion.forEach(buttonWithQuestion => {
                    buttonWithQuestion.classList.add('btn-primary');
                    buttonWithQuestion.classList.remove('btn-secondary');
                    buttonWithQuestion.disabled = false;
                });
            }
        }
        if (activeTeam.play_status === '2') {
            buttonsAnswer.forEach(buttonAnswer => {
                buttonAnswer.disabled = false;
            });
        }
    });
}, 1000);

// интервал для модального окна
const intervalModalWindow = setInterval(() => {
    // получаем id активного вопроса
    ajaxRequest('room/check_id_question_active', { id_room: idRoom }).then(idQuestionActive => {
        if (idQuestionActive.error) {
            console.error(idQuestionActive.error);
        } else {
            // Делаем проверку на данные, которые вернуло
            if (idQuestionActive !== 'NULL') {
                // Получаем вопрос
                ajaxRequest('room/get_answer', { id_question: idQuestionActive }).then(questionActive => {
                    if (questionActive.error) {
                        console.error(questionActive.error);
                    } else {
                        // Получаем варианты ответа
                        ajaxRequest('room/get_answer_options', { id_question: questionActive.id }).then(questionOptions => {
                            if (questionOptions.error) {
                                console.error(questionOptions.error);
                            } else {
                                // выводим окошко с вариантами ответов
                                modalWindow.classList.add('d-flex');
                                modalWindow.style.height = `calc(100vh - ${heightHeader}px`;
                                modalWindow.style.top = heightHeader + 'px';
                                answerOptions = questionOptions.answer_options;
                                questionNameArea.textContent = questionActive.name;
                                // выводим варианты ответов для каждой кнопки
                                buttonsAnswer.forEach(buttonAnswer => {
                                    buttonAnswer.textContent = '';
                                    answerOption = answerOptions[0];
                                    buttonAnswer.textContent = answerOption.name;
                                    buttonAnswer.id = 'answer-option[' + answerOption.id + ']';
                                    answerOptions.splice(0, 1);
                                });
                            }
                        });
                    }
                });
            }
        }
    });
}, 1000);

// Добавляем EventListener для каждой кнопки
buttonsWithQuestion.forEach(buttonWithQuestion => {
    buttonWithQuestion.addEventListener('click', (e) => {
        // Получаем id вопроса
        idQuestion = buttonWithQuestion.id.split('[')[1].slice(0, -1);
        // проверяем на возможность выбора кнопки 
        ajaxRequest('room/check_answer_possibility').then(team => {
            if (team.error) {
                console.error(team.error);
            } else {
                // если все окей, то продолжаем
                team['play_status'] = '2';
                // обновляем play_status
                ajaxRequest('room/update_team_play_status', { team }).then(answer => {
                    if (answer.error) {
                        console.error(answer.error);
                    } else {
                        // если получилось его обновить
                        // обновляем id_question_active
                        params = {id_question: idQuestion, id_room: idRoom};
                        // обновляем активный вопрос в базе данных
                        ajaxRequest('room/update_id_question_active', params).then(answer => {
                            if (answer.error) {
                                console.error(answer.error);
                            }
                        }); 
                    }
                });
            }
        });
    });
});

buttonsAnswer.forEach(buttonAnswer => {
    // теперь для каждой кнопки делаем слушатель события как и с кнопками выше
    buttonAnswer.addEventListener('click', (e) => {
        ajaxRequest('room/check_answer_possibility').then(team => {
            if (team.error) {
                console.error(team.error);
            } else {
                answerOptionId = buttonAnswer.id.split('[')[1].slice(0, -1);
                ajaxRequest('room/create_answer', { id_answer_option: answerOptionId }).then(answer => {
                    if (answer.error) {
                        console.error(answer.error);
                    } else {
                        console.log(answer.id_last);
                        ajaxRequest('room/check_answer_option', { id_answer_option: answerOptionId }).then(answer => {
                            if (answer.error) {
                                console.error(answer.error);
                            } else {
                                if (answer === true) {

                                } else {
                                    ajaxRequest('room/update_left_queue', { left_queue: '-' }).then(answer => {
                                        if (answer.error) {
                                            console.error(answer.error);
                                        } else {
                                            team['play_status'] = '0';
                                            console.log(team);
                                            // ajaxRequest('room/update_team_play_status', team) {
                                            
                                            // }
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
            }
        })
    });
});