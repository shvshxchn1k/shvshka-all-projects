import '/js/functions.js';
let id = getCollectionIdByUrl();
id = Number(id);
let params = {id: id};
const intervalId = setInterval(() => {
    ajaxRequest('room/wait', params).then(room => {
        if (room) {
            if (room.play_status === '2'){
                window.location.href = `/room/play/${room.id}`;
            }
        }
    });
}, 1000);