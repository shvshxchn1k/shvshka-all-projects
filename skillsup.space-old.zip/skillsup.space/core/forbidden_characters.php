<?php
$forbidden_characters = ['"', "'", '|', '<', '>', '*'];
