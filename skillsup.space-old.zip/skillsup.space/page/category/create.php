<?php
$id_collection = make_only_number($navs[2]);
$access_user = check_user($_SESSION['user']['id'], $id_collection, $connect);
if ($access_user == true) {
    $access_create = check_create($id_collection, $connect);
    if ($access_create == true) {
?>
        <h1>Шаг 2 | Создание категорий</h1>
        <form action="/category/save/" method="post">
        <input type="hidden" value="<?php echo htmlspecialchars(make_only_number($navs[2])); ?>" name="id_collection">
        <table>
            <thead>
                <tr>
                    <th scope="col">Название первой категории</th>
                    <th scope="col">Название второй категории</th>
                    <th scope="col">Название третий категории</th>
                    <th scope="col">Название четвертой категории</th>
                </tr>
            </thead>
            <tbody>
            <?php
                echo '<tr>';
                for ($row = 1; $row < 5; $row++) {
                    echo '<td>';
                            echo '<input type="text" class="form-control"
                            placeholder="Категория" 
                            name="category[' . $row . ']" 
                            value="cat' . $row . '">';
                    echo '</td>';
                }
                echo '</tr>';
            ?>
            </tbody>
        </table>
        <input type="submit" class="btn btn-success">
        </form>
    <?php 
    } else {
        echo $access_create;
    }
} else {
    echo $access_user;
}