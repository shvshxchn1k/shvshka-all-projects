<?php
if ($_POST) {
    $id_collection = make_only_number($_POST['id_collection']);
    $access_user = check_user($_SESSION['user']['id'], $id_collection, $connect);
    if ($access_user == true) {
    $categories = $_POST['category'];
    $last_ids = [];
    foreach ($categories as $category) {
        $category = [
            'name' => $category,
            'id_collection' => $id_collection,
            'status' => '1'
        ];
        $last_id = sql_insert($category, 'category', $connect);
        $last_ids[] = $last_id;
    }
    $params = $id_collection . '_' . $last_ids[0];
    echo '<meta http-equiv="refresh" content="1;URL=/question/create/' . htmlspecialchars($params) .'"/>';
    } else {
        echo $access_user;
    }
} else {
    require_once 'component/no_post.php';    
}