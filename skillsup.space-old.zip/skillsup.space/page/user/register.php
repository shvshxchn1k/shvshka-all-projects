<form method="post" action="">
    <div class="mb-3">
        <label for="email" class="form-label">Электронная почта:</label>
        <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name="email" placeholder="Введите вашу электронную почту" required>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Пароль:</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Введите ваш пароль" required>
    </div>
    <button type="submit" class="btn btn-success">Зарегистрироваться</button>
</form>
<br>
<h2>Уже есть учетная запись?</h2>
<a href="/user/login/" class="btn btn-primary">Войти</a>
<?php
if ($_POST) {
    $user_data = $_POST;
    $user = sql_select('email', $user_data['email'], 'user', $connect);
    if ($user) {
        alert_bootstrap_red('Пользователь с такой почтой уже существует, попробуйте другую');
    } else {
        $nickname = create_number(6);
        $user_data['nickname'] = $nickname;
        $user_data['status'] = '1';
        $last_id = sql_insert($user_data, 'user', $connect);
        $user = sql_select('id', $last_id, 'user', $connect);
        $_SESSION['user'] = $user;
        echo '<meta http-equiv="refresh" content="0;URL=/collection/list/"/>';
    }
}