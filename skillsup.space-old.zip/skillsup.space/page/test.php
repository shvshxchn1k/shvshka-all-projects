<?php
$team['id_room'] = 31;
$room = sql_select('id', $team['id_room'], 'room', $connect);
$set = [
    'id_question_active' => $id_question
];
$where = [
    'id' => $room['id']
];
$answer = sql_update($set, $where, 'room', $connect);
if ($answer) {
    dump_array(123);
}