<link rel="stylesheet" href="/css/test-result.css">
<?php
if ($_POST) {
    $meanings = $_POST['meaning'];
    $id_kit = $navs[2];
    $right_answers = 0;
    $false_answers = 0;
    $no_answer = 0;
    $cards = sql_select('id_kit', $id_kit, 'card', $connect);
    foreach ($meanings as $id_meaning => $meaning) {
        foreach ($cards as $card) {
            if ($id_meaning == $card['id']) {
                if ($meaning == $card['meaning']) {
                    $right_answers++;
                } else {
                    if (empty($meaning)) {
                        $no_answer++;
                    } else {
                        $false_answers++;
                    }
                }
            }
        }
    }
    $answers = [
        'right' => $right_answers,
        'false' => $false_answers,
        'no' => $no_answer
    ];
    $quantity_answers = count($cards);
    $right_answers = ($right_answers / $quantity_answers)*100;
    if ($right_answers >= 90) {
        $mark = '5';
    } elseif ($right_answers < 90 and $right_answers >= 75) {
       $mark = '4';
    } elseif ($right_answers < 75 and $right_answers >= 50) {
        $mark = '3';
    } elseif ($right_answers < 50) {
        $mark = '2';
    }
    $no_answer = ($no_answer / $quantity_answers)*100;
    $false_answers = ($false_answers / $quantity_answers)*100 ;
    ?>
    <div id="results">
        
        <div id="line-result">
            <div id="result-true" class="bg-success" style="width: <?php echo htmlspecialchars($right_answers) . '%'; ?>"></div>
            <div id="result-no" class="bg-secondary" style="width: <?php echo htmlspecialchars($no_answer) . '%'; ?>"></div>
            <div id="result-false" class="bg-danger" style="width: <?php echo htmlspecialchars($false_answers) . '%'; ?>"></div>
        </div>
    </div>
    <div id="result-text">
        <h1>Ваша оценка: <?php echo htmlspecialchars($mark); ?></h1>
        <div class="line-result-text">
            <h4 class="text-success">Правильные ответы: <?php echo htmlspecialchars($answers['right']) ?></h4>
            <h4 class="text-secondary">Не отвечено: <?php echo htmlspecialchars($answers['no']) ?></h4>
            <h4 class="text-danger">Неправильные ответы: <?php echo htmlspecialchars($answers['false']) ?></h4>
        </div>
    </div>
    <div class="row">
        <a href="/kit/test/<?php echo htmlspecialchars($id_kit); ?>" class="col btn btn-success">Перепройти</a>
        <a href="/kit/list/" class="col btn btn-primary">К списку Наборов</a>
    </div>
    <?php
} else {
    alert_bootstrap_red('Ответы не пришли на данную страницу');
}