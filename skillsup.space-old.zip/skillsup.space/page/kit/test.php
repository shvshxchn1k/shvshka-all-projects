<link href="/css/card-test.css" rel="stylesheet">
<?php
$id_kit = $navs[2];
$cards = sql_select('id_kit', $id_kit, 'card', $connect);
echo '<div class="card-test-area d-flex">';
foreach ($cards as $card) {
    $meanings = [];
    $cards_and_meanings = $cards;
    $meanings[] = $card['meaning'];
    while (count($meanings) < 4) {
        shuffle($cards_and_meanings);
        if ($meanings[0] != $cards_and_meanings[0]['meaning']) {
            $meanings[] = $cards_and_meanings[0]['meaning'];
            unset($cards_and_meanings[0]);
        }
    }
    shuffle($meanings);
?>
    <div class="card-test bg-body-tertiary" id="card-test[<?php echo htmlspecialchars($card['id']); ?>]">
        <h1><?php echo htmlspecialchars($card['name']); ?></h1>
        <div class="d-flex meaning-area">
            <?php
            $i = 0;
                foreach ($meanings as $meaning) {
                    if ($i == 0 or $i == 2) {
                        echo '<div class="col-meaning">';
                    }
                    echo '<div type="button" class="btn btn-secondary button-meaning">' . htmlspecialchars($meaning) . '</div>';
                    if ($i == 1 or $i == 3) {
                        echo '</div>';
                    }
                    $i++;
                }
            ?>
        </div>
    </div>
<?php } ?>
</div>
<form action="/kit/test_result/<?php echo htmlspecialchars($id_kit); ?>" method="POST">
    <div class="done-area d-flex">
        <?php foreach ($cards as $card) { ?>
            <input type="hidden" name="meaning[<?php echo htmlentities($card['id']); ?>]" id="meaning[<?php echo htmlentities($card['id']); ?>]" value="">
        <?php } ?>
        <input type="submit" class="btn btn-success" value="Проверить">
    </div>
</form>
<script src="/js/card_test.js" type="module"></script>