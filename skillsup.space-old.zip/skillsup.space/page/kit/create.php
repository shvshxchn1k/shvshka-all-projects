<h1>Создание нового набора карточек</h1>
<form action="/kit/save/" method="POST">
    <div class="mb-3">
        <label for="name-kit" class="form-label">Название набора:</label>
        <input type="text" class="form-control" id="name-kit" name="name_kit" placeholder="Название набора" required>
    </div>
    <button type="button" id="card-create" class="btn btn-primary">Создать новую карточку</button>
    <button type="button" id="card-delete" class="btn btn-danger">Удалить карточку</button>
    <input type="submit" class="btn btn-success" value="Сохранить">
    <table class="table">
        <thead>
            <th scope="col">#</th>
            <th scope="col">Слово</th>
            <th scope="col">Значение/Перевод слова</th>
        </thead>
        <tbody id="card-table">
            <?php 
            for ($i = 1; $i <= 5; $i++) { ?>
            <tr>
                <th scope="row"><?php echo $i; ?></th>
                <td><input type="text" class="form-control" placeholder="Слово" name="word[<?php echo $i; ?>][name]" required></td>
                <td><input type="text" class="form-control" placeholder="Значение/Перевод слова" name="word[<?php echo $i; ?>][meaning]" required></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</form>
<script type="module" src="/js/create_kit.js"></script>