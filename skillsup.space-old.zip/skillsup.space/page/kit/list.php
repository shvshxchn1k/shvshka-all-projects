<?php
if (!empty($_SESSION['user']['id'])) {
    echo '<h1>Список наборов пользователя: <a href="/user/profile/' . htmlspecialchars($_SESSION['user']['nickname']) . '" class="text-info text-decoration-none">' . htmlspecialchars($_SESSION['user']['nickname']) . '</a></h1>';
    echo '<a href="/kit/create" class="btn btn-primary">Создать набор</a>';
    $kits = sql_select('id_creator', $_SESSION['user']['id'], 'kit', $connect);
    if ($kits) {
        echo '<table class="table">';
        echo '
            <thead>
                <th scope="col">#</th>
                <th scope="col">Карточки</th>
                <th scope="col">Запустить тест</th>
            </thead>
            <tbody>
        ';
        $num = 1;
        foreach ($kits as $kit) {
            echo '<tr>';
            echo '<th scope="row">' . $num . '</th>';
            echo '<td><a href="/kit/open/' . htmlspecialchars($kit['id']) . '" class="btn btn-primary">' . htmlspecialchars($kit['name']) . '</td>';
            echo '<td><a href="/kit/test/' . htmlspecialchars($kit['id']) . '" class="btn btn-success">Запустить</td>';
            echo '</tr>';
            $num++;
        }
    echo '</tbody></table>';
    } else {
        alert_bootstrap_blue('Не создано ни одного набора карточек. Создайте его!');
    }    
} else {
    alert_bootstrap_red('Сначала войдите в аккаунт');
}