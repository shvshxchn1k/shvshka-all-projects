<?php 
if ($_POST) {
    $words = $_POST['word'];
    if (count($words) < 5) {
        alert_bootstrap_red('Нельзя меньше 5 карточек, пересоздайте еще раз');
    } else {
        $kit = [
            'id_creator' => $_SESSION['user']['id'],
            'name' => $_POST['name_kit'],
            'status' => '1'
        ];
        $last_id = sql_insert($kit, 'kit', $connect);
        $answer[] = $last_id;
        foreach ($words as $word) {
            $card = [
                'id_kit' => $last_id,
                'name' => $word['name'],
                'meaning' => $word['meaning'],
                'status' => '1'
            ];
            $answer[] = sql_insert($card, 'card', $connect);
        }
        $re_adress = true;
        foreach ($answer as $check) {
            if (is_string($check)) {
                $re_adress = false;
            }
        }
        if ($re_adress) {
            echo '<meta http-equiv="refresh" content="0.1;URL=/kit/open/' . $last_id . '"/>';
        }
    }
}