<?php
if ($_POST) {
    $last_ids = explode('_', $_POST['last_id']);
    $last_ids = make_only_number($last_ids);
    $key = array_keys($_POST['question']);
    $key = $key[0];
    $questions = $_POST['question'][$key];
    foreach ($questions as $key => $question) {
        $question = [
            'name' => $question,
            'id_category' => $last_ids[1],
            'price' => $key,
            'status' => '1'
        ];
        $result = sql_insert($question, 'question', $connect);
    }
    $categories = sql_select('id_collection', $last_ids[0], 'category', $connect);
    $id_first_category = $categories[0]['id'];
    $categories = check_category($categories, $last_ids[1]);
    if (empty($categories)) {
        echo '<meta http-equiv="refresh" content="0;URL=/answer_option/create/' . htmlspecialchars($last_ids[0]) . '_' . htmlspecialchars($id_first_category) .'"/>';
    } else {
        $last_ids = $last_ids[0] . '_' . $categories[0]['id'];
        echo '<meta http-equiv="refresh" content="0;URL=/question/create/' . htmlspecialchars($last_ids) .'"/>';
    }
} else {
    require_once 'component/no_post.php'; 
}