<?php
$params = explode('_', $navs[2]);
$params = make_only_number($params);
$access_user = check_user($_SESSION['user']['id'], $params[0], $connect);
if ($access_user == true) {
    $access_create = check_create($params[0], $connect);
    if ($access_create == true) {
    $category = sql_select('id', $params[1], 'category', $connect);
    if ($category) {
        echo '<h1>Шаг 3 | Создание вопросов для категории ' . htmlspecialchars($category['name']) . '</h1>';
        echo '<form action="/question/save/" method="post">';
        echo '<input type="hidden" value="' . htmlspecialchars($params[0]) . '_' . htmlspecialchars($params[1]) . '" name="last_id">';
        echo '<table class="table">';
        echo '
            <thead>
                <tr>';
        for ($cell = 100; $cell <= 500; $cell += 100) {
            echo '<th scope="col">Вопрос за ' . $cell . '</th>';
        }
        echo    '</tr>
            </thead>';
        echo '
            <tbody>
                <tr>';
            for ($cell = 100; $cell <= 500; $cell += 100) {
                echo '<td><input type="text" class="form-control" name="question[' . htmlspecialchars($category['id']) . '][' . htmlspecialchars($cell) . ']" placeholder="Вопрос стоящий ' . htmlspecialchars($cell) .  '" value="question[' . htmlspecialchars($category['id']) . '][' . htmlspecialchars($cell) . ']" required></td>';
            }
        echo '
                </tr>
            </tbody>';
        echo '</table>';
        echo '<input type="submit" class="btn btn-success">';
        echo '</form>';
        } else {
        echo $access_create;
    }
    } else {
        echo $access_user;
    }
}