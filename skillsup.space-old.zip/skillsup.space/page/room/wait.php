<?php
$id_room = make_only_number($navs[2]);
$room = sql_select('id', $id_room, 'room', $connect);
if ($room) {
    echo 'Ждем пока организатор запустит игру.';
} else {
    alert_bootstrap_red('Нет такой комнаты');
}
?>
<script type="module" src="/js/wait.js"></script>
