<?php
if ($_POST) {
    $code = make_only_number($_POST['code']);
    $room = sql_select('code', $code, 'room', $connect);
    if ($room) {
        if ($room['code'] == $code and $room['play_status'] == 1) {
            echo '<form action="/room/save_team/' . htmlspecialchars($room['id']) .  '" method="post">';
            echo '<label for="name" class="form-label"><h1>Название вашей команды:</h1></label><input type="text" class="form-control" id="name" name="name" placeholder="Название вашей команды" required>';
            echo '<input type="submit" class="btn btn-success" value="Сохранить">';
            echo '</form>';
        }
    }
} else {
    require_once 'component/no_post.php';
}
