<style>
    .disabled-link {
        pointer-events: none;
        cursor: default;
    }
</style>
<?php
$id_room = $navs[2];
$room = sql_select('id', $id_room, 'room', $connect);
if ($room) {
    if ($room['id_creator'] == $_SESSION['user']['id']) {
        if ($room['play_status'] == 1) {
            alert_bootstrap_blue('Для запуска игры необходимо минимум 2 команды');
            echo 'Код для присоединения к комнате: ' . htmlspecialchars($room['code']);
            echo '<br>';
            echo '<a href="/room/update_play_status/' . htmlspecialchars($room['id']) .  '" class="btn btn-success disabled-link">Начать игру</a>';
            echo '<br>';
            echo '<ol id="list"></ol>';
        } else {
            if ($room['play_status'] == 0) {
                alert_bootstrap_red('Данная игра закончена');
            } elseif ($room['play_status'] == 2) {
                alert_bootstrap_red('Данная игра уже начата');
            }
        }
    } else {
        alert_bootstrap_red('Отказано в доступе');
    }
}
?>
<script src="/js/start.js" type="module"></script>
