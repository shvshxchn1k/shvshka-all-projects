<?php
if ($_POST) {
    $id_room = $navs[2];
    $name = $_POST['name'];
    $id_creator = $_SESSION['user']['id'];
    $team = [
        'id_room' => $id_room,
        'id_creator' => $id_creator,
        'name' => $name,
        'status' => '1'
    ];
    $teams = sql_select('id_room', $id_room, 'team', $connect);
    if (!$teams) $team['play_status'] = '1';
    $last_id = (sql_insert($team, 'team', $connect));
    $team = sql_select('id', $last_id, 'team', $connect);
    $_SESSION['team'] = $team;
    echo '<meta http-equiv="refresh" content="0;URL=/room/wait/' . $id_room .  '"/>';
} else {
    require_once 'component/no_post.php';
}

