<?php
$id_collection = make_only_number($navs[2]);
$code = create_number(6);
$room = [
    'id_creator' => $_SESSION['user']['id'],
    'id_collection' => $id_collection,
    'code' => strval($code),
    'play_status' => '1',
    'status' => '1'
];
$id_last = sql_insert($room, 'room', $connect);
$_SESSION['room_admin'] = $id_last;
$_SESSION['team']['name'] = 'admin';
echo '<meta http-equiv="refresh" content="1;URL=/room/start/' . $id_last . '"/>';