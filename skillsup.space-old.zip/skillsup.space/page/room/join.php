<form action="/room/check_join/" method="post">
    <label for="code" class="form-label"><h1>Код комнаты для присоединения:</h1></label>
    <input type="text" class="form-control" id="code" name="code" placeholder="Код комнаты для присоединения">
    <input type="submit" class="btn btn-success" value="Подключиться">
</form>