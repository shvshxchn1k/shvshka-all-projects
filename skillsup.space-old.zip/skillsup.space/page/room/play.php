<link rel="stylesheet" href="/css/play.css" type="text/css">
<?php
$id_room = $navs[2];
$room = sql_select('id', $id_room, 'room', $connect);
$teams = sql_select('id_room', $room['id'], 'team', $connect);
if (count($teams) > 1) {
    $id_collection = $room['id_collection'];
    $collection = sql_select('id', $id_collection, 'collection', $connect);
    echo '<h1>Название ' . htmlspecialchars($collection['name']) . '</h1>';
    $categories = sql_select('id_collection', $collection['id'], 'category', $connect);
    foreach ($categories as $category) {
        $questions_in_foreach = sql_select('id_category', $category['id'], 'question', $connect);
        $questions[] = $questions_in_foreach;
    }
    $questions = array_merge(...$questions);
    echo '<table class="table">';
    foreach ($categories as $category) {
        $price = 100;
        echo '<tr>';
        echo '<th scope="row">' . htmlspecialchars($category['name']) . '</th>';
        foreach ($questions as $question) {
            if ($price == 600){
                $price = 100;
            }
            if ($question['id_category'] == $category['id'] and $question['price'] == $price) echo '<td><button class="btn btn-secondary btn-with-question" id="question[' . htmlspecialchars($question['id']) . ']" disabled>' . htmlspecialchars($question['price']) . '</button></td>';
            $price += 100;
        }
        echo '</tr>';
    }
    echo '</table>';
    ?>
    <h1 id="queue_text"></h1>
    <div class="container text-center" id="teams-names-area">
        <div class="row align-items-start">
            <?php
            foreach ($teams as $team) {
                $active_team_classes = ($teams[0]['id'] == $team['id']) ? 'text-success active-team' : '';
                echo '<div class="col '. $active_team_classes .'" id="team[' . htmlspecialchars($team['id']) .  ']">';
                if ($team['name'] == $_SESSION['team']['name']) {
                    echo '<div class="your-team">Ваша команда</div>';
                } 
                echo htmlspecialchars($team['name']) . ': <div class="team" id="score[' . htmlspecialchars($team['id']) . ']">' . htmlspecialchars($team['score']) . '</div></div>';
            }
            ?>
        </div>
    </div>
    <script type="module" src="/js/play.js"></script>
<?php
} else {
    alert_bootstrap_red('Команд участвующих в игре слишком мало! Необходимо минимум две');
}
?>
<div id="modal-window" style="display: none">
    <div class="row">
        <h1 class="col text-center" id="question-name"></h1>
    </div>
    <div class="row">
        <h2 class="col text-center" id="answering-team"></h2>
    </div>
    <div class="row" id="answers-buttons">
        <div class="col">
            <button type="button" class="btn btn-info button-answer" disabled></button>
            <button type="button" class="btn btn-info button-answer" disabled></button>
            <button type="button" class="btn btn-info button-answer" disabled></button>
        </div>
    </div>
</div>