<?php
$id_room = make_only_number($navs[2]);
$room = sql_select('id', $id_room, 'room', $connect);
if ($room) {
    $id_room = $room['id'];
    $set = [
        'play_status' => 2
    ];
    $where = [
        'id' => $id_room
    ];
    $answer = sql_update($set, $where, 'room', $connect);
    if ($answer) {
        echo '<meta http-equiv="refresh" content="0;URL=/room/play/' . htmlspecialchars($id_room) .  '"/>';
    } else {
        echo $answer;
    }
} else {
    alert_bootstrap_red('Такой комнаты не сущестует, попробуйте пересоздать ее');
}

