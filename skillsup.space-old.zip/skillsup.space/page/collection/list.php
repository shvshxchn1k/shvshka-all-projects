<?php
    $id_user = $_SESSION['user']['id'];
    if (!empty($id_user)) {
        $nickname = $_SESSION['user']['nickname'];
        echo '<h1>Список коллекций пользователя: <a href="/user/profile/' . htmlspecialchars($nickname) . '" class="text-info text-decoration-none">' . htmlspecialchars($nickname) . '</h1>';
        echo '<a href="/collection/create" class="btn btn-primary">Создать новую коллекцию</a>';
        $collections = sql_select('id_creator', $id_user, 'collection', $connect);
        if ($collections) { ?>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Имя</th>
                <th scope="col">Запуск</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $i = 1;
                foreach ($collections as $collection) {
                    echo '<tr>';
                    echo '<th scope="row">' . $i . '</th>';
                    echo '<td><a href="/collection/open/' . htmlspecialchars($collection['id']) . '" class="btn btn-primary">' . htmlspecialchars($collection['name']) . '</td>';
                    echo '<td><a href="/room/create/' . htmlspecialchars($collection['id']) . '" class="btn btn-success">Запустить игру</a></td>';
                    echo '</tr>';
                    $i++;
                }
            ?>
        </tbody>
    </table>
<?php 
    }
} else {
    alert_bootstrap_red('Сначала войдите в аккаунт');
}