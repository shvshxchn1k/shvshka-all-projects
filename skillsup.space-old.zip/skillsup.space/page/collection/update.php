<?php
if ($navs[2]) {
    if ($_POST) {
        $access_user = check_user($_SESSION['user']['id'], $navs[2], $connect);
        if ($access_user) {
            // Получаем данные из POST
            $name_collection = $_POST['collection_name'];
            $categories = $_POST['category'];
            $questions = $_POST['question'];
            $id_collection = make_only_number($navs[2]);
            // Получаем данные про коллекцию из базы данных
            $collection = sql_select('id', $id_collection, 'collection', $connect);
            if ($collection['name'] != $name_collection) {
                $set = [
                    'name' => $name_collection
                ];
                $where = [
                    'id' => $id_collection
                ];
                $answer = sql_update($set, $where, 'collection', $connect);
            }
            // Делаем update в категории
            foreach ($categories as $key => $value) {
                $category = sql_select('id', $key, 'category', $connect);
                if ($category['name'] != $value) {
                    $set = [
                        'name' => $value,
                    ];
                    $where = [
                        'id' => $category['id']
                    ];
                    $answer = sql_update($set, $where, 'category', $connect);
                }
            }
            foreach ($questions as $key => $value) {
                $question = sql_select('id', $key, 'question', $connect);
                if ($question['name'] != $value) {
                    $set = [
                        'name' => $value
                    ];
                    $where = [
                        'id' => $question['id']
                    ];
                    $answer = sql_update($set, $where, 'question', $connect);
                }
            }
            echo '<meta http-equiv="refresh" content="0;URL=/collection/open/' . htmlspecialchars($collection['id']) .'"/>';
        } else {
            echo $access_user;
        }
    } else {
        alert_bootstrap_red('Post не пришел на данную страницу');
    }
} else {
    alert_bootstrap_red('Не указан id таблицы');
}
