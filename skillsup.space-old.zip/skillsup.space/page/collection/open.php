<?php
$id_collection = make_only_number($navs[2]);
$id_user = $_SESSION['user']['id'];
$user_access = check_user($id_user, $id_collection, $connect); 
if ($user_access) {
    $answer = get_collection($id_collection, $connect);
    $collection = $answer['collection'];
    $categories = $answer['categories'];
    $questions = $answer['questions'];
    echo '<h1>Редактирование коллекции: <span class="text-info">' . htmlspecialchars($collection['name']) . '</span></h1>';
    echo '<table class="table">';
    ?>
        
    <thead>
    <tr>
        <th scope="col">Категории</th>
        <th scope="col">Вопрос за 100</th>
        <th scope="col">Вопрос за 200</th>
        <th scope="col">Вопрос за 300</th>
        <th scope="col">Вопрос за 400</th>
        <th scope="col">Вопрос за 500</th>
    </tr>
    </thead>
    <?php
    foreach ($categories as $category) {
        $id_category = $category['id'];
        echo '<tr>';
        echo '<th scope="row">' . htmlspecialchars($category['name']) . '</th>';
        foreach ($questions[$id_category] as $question) {
            echo '<td><a href="/answer_option/open/' . htmlspecialchars($question['id']) . '" class="btn btn-primary">'  .  htmlspecialchars($question['name']) .  '</a></td>';
        }
        echo '</tr>';
    }
    echo '</table>';
    echo '<div class="row">';
    echo '<a href="/collection/edit/' . htmlspecialchars(make_only_number($id_collection)) . '" class="col btn btn-success">Редактировать</a>';
    echo '<a href="/collection/list" class="col btn btn-primary">К списку колекций</a>';
    echo '</div>';
} else {
    echo $user_access;
}
