<?php
$id_collection = make_only_number($navs[2]);
$access_user = check_user($_SESSION['user']['id'], $id_collection, $connect);
if ($access_user) {
    $collection = sql_select('id', $id_collection, 'collection', $connect);
    if ($collection) {
        echo '<h1>Редактирование колекции <span class="text-info">«' . htmlspecialchars($collection['name']) . '»</span></h1>';
        $categories = sql_select('id_collection', $id_collection, 'category', $connect);
        if ($categories) {
            $questions = [];
            foreach ($categories as $key => $category) {
                $questions_result = sql_select('id_category', $category['id'], 'question', $connect);
                foreach ($questions_result as $param => $value) {
                    $value = [
                    'id' => $value[0],
                    'id_category' => $value[1],
                    'name' => $value[2],
                    'image' => $value[3],
                    'price' => $value[4],
                    'status' => $value[5]
                    ];
                    $question[$param] = $value;
                }
                $questions[$category['id']] = $question;
            }
            echo '<form action="/collection/update/' . htmlspecialchars($collection['id']) . '" method="POST">';
            echo 'Название: <input type="text" class="form-control" name="collection_name" value="' . htmlspecialchars($collection['name']) . '">';
            echo '<table class="table">';
    ?>
        <thead>
        <tr>
            <th scope="col">Категории</th>
            <th scope="col">Вопрос за 100</th>
            <th scope="col">Вопрос за 200</th>
            <th scope="col">Вопрос за 300</th>
            <th scope="col">Вопрос за 400</th>
            <th scope="col">Вопрос за 500</th>
        </tr>
        </thead>
    <?php
        foreach ($categories as $key => $category) {
            echo '<tr>';
            echo '<th scope="row"><input class="form-control" value="' . htmlspecialchars($category['name']) . '" name="category[' . htmlspecialchars($category['id']) . ']"></th>';
            foreach ($questions[$category['id']] as $question) {
                echo '<td><input class="form-control" name="question[' . htmlspecialchars($question['id']) . ']" value="' . htmlspecialchars($question['name']) . '"></td>';
            }
            echo '</tr>';
        }
        echo '</table>';
        echo '<button class="btn btn-success" type="submit">Сохранить</button>';
        echo '</form>';
        } else {
            alert_bootstrap_red('Нет коллекции с таким id');
        }
    } else {
        alert_bootstrap_red('Не получилось получить доступ к коллекции');
    }
} else {
    echo $access_users;
}