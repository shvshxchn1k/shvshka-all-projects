<h1>Шаг 1 | Создание коллекции</h1>
<form action="save" method="post">
    <label for="collection_name" class="form-label">Название коллекции:</label>
    <input class="form-control" type="text" name="collection_name" id="collection_name" placeholder="Название коллекции" required>
    <input type="submit" class="btn btn-success">
</form>