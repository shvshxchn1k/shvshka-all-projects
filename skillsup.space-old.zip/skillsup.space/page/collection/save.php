<?php
if ($_POST) {
    $name = $_POST['collection_name'];
    $array = [
        'id_creator' => $_SESSION['user']['id'],
        'name' => $name,
        'status' => '1'
    ];
    $last_id = sql_insert($array, 'collection', $connect);
    if ($last_id) {
        echo '<meta http-equiv="refresh" content="1;URL=/category/create/' . $last_id .'"/>';
    }
} else {
    require_once 'component/no_post.php';
}