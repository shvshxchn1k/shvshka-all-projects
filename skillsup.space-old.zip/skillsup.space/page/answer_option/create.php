<?php
$ids = explode('_', $navs[2]);
$ids = make_only_number($ids);
$category = sql_select('id', $ids[1], 'category', $connect);
echo '<h1>Шаг 5 | Создание ответов на вопросы категории ' . htmlspecialchars($category['name']) . '</h1>';
$questions = sql_select('id_category', $category['id'], 'question', $connect);
$main_category = $category['id'];
if ($category) {
    echo '<form action="/answer_option/save/" method="post">';
    echo '<input type="hidden" value="' . htmlspecialchars($main_category) . '" name="id_category">';
    echo '
        <table class="table">
            <thead>
                <tr>';
                foreach ($questions as $key => $question) {
                    echo '<th scope="col">' . htmlspecialchars($question['name']) . '</th>';
                }
    echo '
                </tr>
            </thead>';
    echo '
            <tbody>
                <tr>';
    foreach ($questions as $key => $question) {
        echo '
                    <td>
                        <input class="form-control border-success" placeholder="Правильный ответ на вопрос ' . htmlspecialchars($question['name']) . '" name="answer_option[' . htmlspecialchars($question['id']) . '][0]" required value="Правильный ответ на вопрос">
                        <input class="form-control border-danger" placeholder="Неправильный ответ на вопрос ' . htmlspecialchars($question['name']) . '" name="answer_option[' . htmlspecialchars($question['id']) . '][1]" required value="неравильный ответ на вопрос1">
                        <input class="form-control border-danger" placeholder="Неправильный ответ на вопрос ' . htmlspecialchars($question['name']) . '" name="answer_option[' . htmlspecialchars($question['id']) . '][2]" required value="неравильный ответ на вопрос2">
                    </td>
                ';
    }
    echo '
                </tr>
            </tbody>';
    echo '
        </table>
        <input type="submit" class="btn btn-success" value="Сохранить">
    </form>';
    } else {
    alert_bootstrap_red('Нужная категория не нашлась в базе данных, попробуйте пересоздать коллекцию');
}
