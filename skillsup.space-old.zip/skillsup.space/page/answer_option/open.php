<?php
$id_question = make_only_number($navs[2]);
$question = sql_select('id', $id_question, 'question', $connect);
$answer_options = sql_select('id_question', $id_question, 'answer_option', $connect);
shuffle($answer_options);
echo '<h1>Предпросмотр вопроса: <span class="text-info">' . htmlspecialchars($question['name']) . '</span></h1>';
echo '<div class="row row-cols-auto g-1">';
foreach ($answer_options as $answer_option) {
    if ($answer_option['is_true'] == 0) {
        $class = 'btn-success';
    } else {
        $class = 'btn-danger';
    }
    echo '<div class="col"><button class="btn ' . $class .'">' .htmlspecialchars($answer_option['name']) . '</button></div>';
}
echo '</div>';
br();
$category = sql_select('id', $question['id_category'],'category', $connect);
if ($category) {
    echo '<div class="row">';
    echo '<a href="/answer_option/edit/' . htmlspecialchars($question['id']) . '" class="btn btn-success col">Редактировать</a>';
    echo '<a href="/collection/open/' . htmlspecialchars($category['id_collection']) . '" class="btn btn-primary col">Назад</a>';
    echo '</div>';
} else {
    alert_bootstrap_red('Ошибка генерации UI элементов');
}
