<?php
$id_question = make_only_number($navs[2]);
$question = sql_select('id', $id_question, 'question', $connect);
echo '<h1>Редактирование вопроса: ' . htmlspecialchars($question['name']) . '</h1>';
$answer_options = sql_select('id_question', $id_question, 'answer_option', $connect);
echo '<form action="/answer_option/update/' . htmlspecialchars($id_question) . '" method="post">';
foreach ($answer_options as $answer_option) {
    echo '<h3>';
    if ($answer_option['is_true'] == 0) {
        echo 'Правильный ответ: ';
        $class = 'border-success';
    } else {
        echo 'Неправильный ответ: ';
        $class = 'border-danger';
    }
    echo '</h3>';
    echo '<input class="form-control" name="answer_option[' . htmlspecialchars($answer_option['id']) .  ']" value="' . htmlspecialchars($answer_option['name']) . '">';
}
echo '<input type="submit" class="btn btn-success" value="Сохранить">';
echo '</form>';