<?php
$new_answer_options = $_POST['answer_option'];
$id_question = make_only_number($navs[2]);
$answer_options = sql_select('id_question', $id_question, 'answer_option', $connect);
$question = sql_select('id', $id_question, 'question', $connect);
$category = sql_select('id', $question['id_category'], 'category', $connect);
$collection = sql_select('id', $category['id_collection'], 'collection', $connect);
foreach ($new_answer_options as $key => $new_answer_option) {
    foreach ($answer_options as $answer_option) {
        if ($answer_option['id'] == $key) {
            if ($answer_option['name'] != $new_answer_option) {
                $where = [
                    'id' => intval($answer_option['id'])
                ];
                $set = [
                    'name' => $new_answer_option
                ];
                $result = sql_update($set, $where, 'answer_option', $connect);
                if ($result === true) {
                    echo '<meta http-equiv="refresh" content="0;URL=/collection/open/' . htmlspecialchars($collection['id']) . '"/>';
                } else {
                    echo $result;
                }
            } else {
                echo '<meta http-equiv="refresh" content="0;URL=/collection/open/' . htmlspecialchars($collection['id']) . '"/>';
            }
        }
    }
}