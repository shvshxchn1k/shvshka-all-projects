<?php
if ($_POST) {
    $id_category = make_only_number($_POST['id_category']);
    $answers_options = $_POST['answer_option'];
    foreach ($answers_options as $answer_key => $answer_options) {
        foreach ($answer_options as $option_key => $answer_option) {
            $answer_option = [
                'id_question' => $answer_key,
                'is_true' => $option_key,
                'name' => $answer_option,
                'status' => '1'
            ];
            $last_id = sql_insert($answer_option, 'answer_option', $connect);
        }
    }
    $category = sql_select('id', $id_category, 'category', $connect);
    $id_collection = $category['id_collection'];
    $categories = sql_select('id_collection', $category['id_collection'], 'category', $connect);
    $categories = check_category($categories, $category['id']);
    if (count($categories) == 0) {
        echo '<a href="/collection/open/' . htmlspecialchars($id_collection) . '" class="btn btn-primary">Проверить коллекцию</a>';
        echo '<a href="collection/list">К списку коллекций</a>';
    } else {
        $last_ids = $category['id_collection'] . '_' . $categories[0]['id'];
        echo '<meta http-equiv="refresh" content="0;URL=/answer_option/create/' . htmlspecialchars($last_ids) .'"/>';
    }
} else {
    require_once 'component/no_post.php';
}