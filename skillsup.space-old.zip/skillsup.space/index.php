<?php include 'config/session_start.php'; ?>
<?php require_once 'config/db_connect.php'; ?>
<?php require_once 'core/functions.php'; ?>

<!DOCTYPE html>
<html lang="ru" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <title>SkillsUp</title>
    <link rel="icon" href="image/site/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="/js/functions.js"></script>
    <script src="/bootstrap-5.3.8-dist/js/bootstrap.bundle.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <!-- <script src="https://kit.fontawesome.com/3e299a4f17.js" crossorigin="anonymous"></script> -->
    <style>
        html, body {
            max-width: 100vw;
            overflow-x: hidden;
        }
        .logo {
            height: 60px;
            width: 125px;
        }
        #logo {
            height: 60px;
            width: 125px;
        }
    </style>
</head>
<body>
    <?php
    require_once 'component/header.php';
    echo '<main class="container" id="main-container">';
    // Получаем адрес ссылки
    $request = $_SERVER['REQUEST_URI'];
    // Удаляем лишнее символы
    $request = trim($request);
    // Удаляем первый символ в ссылке
    $request = substr($request,1);
    // Делим строку по символу: '/'
    $navs = explode('/', $request);
    $dir = 'page/';
    $filename = $dir . $navs[0];
    if (isset($navs[1])) $filename .= '/' . $navs[1];
    $filename .= '.php';
    // Проверяем на несуществование файла
    if (empty($navs[0])) $filename = $dir . 'main.php';
    if (!file_exists($filename)) {
        $filename = $dir . '404.php';
    }
    // подключаем файл
    require_once $filename;
    echo '</main>';
    // require_once 'component/footer.php';
    ?>
    <script>
        const header = document.getElementById('header');
        const heightHeader = header.offsetHeight;
        const mainContainer = document.getElementById('main-container');
        mainContainer.style.marginTop = heightHeader + 'px';
        mainContainer.style.minHeight = 'calc(100vh - ' + heightHeader + ')'; 
    </script>
</body>
</html>