<?php
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
$id_question = $data['id_question'];
if ($id_question > 0 && isset($id_question)) {
    $question = sql_select('id', $id_question, 'question', $connect);
    $answer = ($question) ? $question : [ 'error' => 'Не получилось получить данные из базы данных' ];
} else {
    $answer['error'] = 'Ошибка полученных данных';
}
echo json_encode($answer);
exit;