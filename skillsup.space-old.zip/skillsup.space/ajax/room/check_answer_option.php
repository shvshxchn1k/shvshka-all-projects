<?php
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
$id_answer_option = $data['id_answer_option'];
if ($id_answer_option) {
    $answer_option = sql_select('id', $id_answer_option, 'answer_option', $connect);
    if ($answer_option) {
        if ($answer_option['is_true'] == '0') {
            $answer = true;
        } else {
            $answer = false;
        }
    } else {
        $answer['error'] = 'Не получилось получить вариант ответа из базы данных';
    }
} else {
    $answer['error'] = 'Не получилось передать данные с фронта';
}
echo json_encode($answer);
exit;