<?php
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
$id_question = $data['id_question'];
$id_room = $data['id_room'];
if ($id_question > 0 && isset($id_question)) {
    $set = [
        'id_question_active' => $id_question
    ];
    $where = [
        'id' => $id_room
    ];
    $answer = sql_update($set, $where, 'room', $connect);
    $answer = ($answer) ? true : [ 'error' => 'Не получилось обновить данные в базе данных' ];
} else {
    $answer['error'] = 'Данные не пришли на страницу';
}
echo json_encode($id_question);
exit;