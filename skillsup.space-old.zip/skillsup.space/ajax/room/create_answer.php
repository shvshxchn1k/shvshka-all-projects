<?php
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
$id_answer_option = $data['id_answer_option'];
if ($id_answer_option) {
    $array = [
        'id_team' => $_SESSION['team']['id'],
        'id_answer_option' => $id_answer_option,
        'status' => '1'
    ];
    $last_id = sql_insert($array, 'answer', $connect);
    $answer['id_last'] = $last_id;
} else {
    $answer['error'] = 'Не получилось получить данные с фронта';
}
echo json_encode($answer);
exit;