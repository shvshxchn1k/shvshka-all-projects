<?php
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
$team = $data['team'];
if ($team) {
    $set = [
        'play_status' => $team['play_status']
    ];
    $where = [
        'id' => $team['id']
    ];
    $answer = sql_update($set, $where, 'team', $connect);
    $answer = ($answer) ? true : [ 'error' => 'Не получилось обновить данные в базе данных' ];
} else {
    $answer = [ 'error' => 'Не пришли данные' ];
}
echo json_encode($answer);
exit;