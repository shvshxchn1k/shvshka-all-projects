<?php
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
$id_question = $data['id_question'];
if (isset($id_question) && $id_question > 0) {
    $answer_options = sql_select('id_question', $id_question, 'answer_option', $connect);
    if ($answer_options) {
        // shuffle($answer_options);
        $answer['answer_options'] = $answer_options;
    } else {
        $answer['error'] = 'Не получилось получить данные из базы данных';
    }
} else {
    $answer['error'] = 'Не получилось получить данные переданные с фронта или данные пришли некоректно';
}
echo json_encode($answer);
exit;