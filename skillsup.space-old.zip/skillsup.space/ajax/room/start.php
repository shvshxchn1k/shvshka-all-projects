<?php
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true); 
$id_room = $data['id_room'];
$teams = sql_select('id_room', $id_room, 'team', $connect);
echo json_encode($teams);
exit;