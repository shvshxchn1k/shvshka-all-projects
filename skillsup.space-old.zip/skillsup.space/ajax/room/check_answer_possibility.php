<?php
// Обновляем play_status на '2'
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
// Получаем команду из сессии
$id_team = $_SESSION['team']['id'];
// Получаем команду из юазы данных
$team = sql_select('id', $id_team, 'team', $connect);
// Делаем проверку на возможномть хода
$answer = (($team['play_status'] == '1' or $team['play_status'] == '2') and $team['left_queue'] != '-') ? $team : [ 'error' => 'Отказ в доступе' ];
echo json_encode($answer);
exit;