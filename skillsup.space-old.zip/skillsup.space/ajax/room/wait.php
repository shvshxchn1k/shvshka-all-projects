<?php
require_once '../../config/db_connect.php';
require_once '../../core/functions.php';
// Получить "сырые" данные JSON
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
$id_room = $data['id'];
$room = sql_select('id', $id_room, 'room', $connect);
$answer = ($room) ? $room : false;
echo json_encode($answer);
exit;