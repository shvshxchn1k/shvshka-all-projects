<?php
// Получаем активную команду
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
$room = sql_select('id', $data['id_room'], 'room', $connect);
$teams = sql_select('id_room', $data['id_room'], 'team', $connect);
foreach ($teams as $team) {
    if (($team['play_status'] == '1' || $team['play_status'] == '2') && $team['left_queue'] != '-') $active_team = $team;
}
if ($room['id_creator'] != $_SESSION['user']['id']) {
    if ($active_team['id'] == $_SESSION['team']['id']) $active_team['session'] = true;
}
echo json_encode($active_team);
exit;