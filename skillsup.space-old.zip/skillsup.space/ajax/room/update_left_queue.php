<?php
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
$left_queue = $data['left_queue'];
if ($left_queue) {
    $set = [
        'left_queue' => $left_queue
    ];
    $where = [
        'id' => $_SESSION['team']['id']
    ];
    $answer = sql_update($set, $where, 'team', $connect);
} else {
    $answer['error'] = 'Не получилось полуить данные с фронта';
}
echo json_encode($answer);