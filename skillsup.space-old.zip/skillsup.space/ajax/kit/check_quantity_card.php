<?php
require_once '../../config/db_connect.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true); 

$id_card = $data['card_id'];
$result = sql_select('id', $id_card, 'card', $connect);
$card = $result->fetch_assoc();
$result = sql_select('id_kit', $card['id_kit'], 'card', $connect);
$cards = $result->fetch_all(MYSQLI_ASSOC);
$count = 0;
foreach ($cards as $card) {
    if ($card['status'] == '1') $count++;
}
$answer = ($count > 5) ? true : false;
echo json_encode($answer);
exit;
