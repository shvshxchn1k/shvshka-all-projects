<?php
alert_bootstrap_yellow('Запрещены символы: < > | * " ' . "'");
