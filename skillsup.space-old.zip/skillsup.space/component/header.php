<nav id="header" style="min-height: 100px; z-index: 1000;" class="navbar navbar-expand-lg bg-body-tertiary fixed-top" data-bs-theme="dark">
    <div class="container">
        <a class="navbar-brand" class="logo" href="/main"><img src="/image/site/logo.png" alt="logo" class="logo" id="logo"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="-collapse -navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                
                    <?php if (!empty($_SESSION)) { ?>
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="/collection/list/"><button class="btn btn-dark">Мои коллекции</button></a></li>
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="/kit/list/"><button class="btn btn-dark">Мои наборы</button></a></li>
                        <li class="nav-item"><a class="nav-link" aria-current="page" href="/user/profile/<?php echo htmlspecialchars($_SESSION['user']['nickname']); ?>"><button class="btn btn-dark">Мой профиль</button></a></li>
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="/user/logout/"><button class="btn btn-dark">Выйти</button></a></li>
                    <?php } else { ?>
                        <li class="nav-item"><a class="nav-link active" href="/user/login/"><button class="btn btn-dark">Войти</button></a></li>
                    <?php } ?>
            </ul>
        </div>
    </div>
</nav>