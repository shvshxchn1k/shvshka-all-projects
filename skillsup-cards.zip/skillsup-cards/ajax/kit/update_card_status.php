<?php
require_once '../../config/db_connect.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
$json = file_get_contents('php://input');
$data = json_decode($json, true); 

$id_card = $data['card_id'];
$result = sql_select('id', $id_card, 'card', $connect);
$card = $result->fetch_assoc();
if ($card['status'] == '1') {
    $status = '0';
} else {
    $status = '1';
}
$status = $card['status'] == '1' ? '0' : '1';
$set = [
    'status' => $status
];
$where = [
    'id' => $id_card
];
$answer = sql_update($set, $where, 'card', $connect);
if ($answer) {
    echo json_encode($status);
} else {
    echo json_encode($answer);
}
exit;
