<?php
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
// Получить "сырые" данные JSON
$json = file_get_contents('php://input');
$data = json_decode($json, true); 

$id_right = $data['id_right'];
$meaning = $data['meaning'];
$result = sql_select('id', $id_right, 'card', $connect);
$right_card = $result->fetch_assoc();
if ($meaning == $right_card['meaning']) {
    $result = sql_select('id_kit', $right_card['id_kit'], 'card', $connect);
    $cards = $result->fetch_all(MYSQLI_ASSOC);
    foreach ($cards as $key => $card) {
        if ($card['id'] <= $right_card['id']) unset($cards[$key]);
    }
    $cards = array_values($cards);
    $answer = $cards[0]['id'];
} else {
   $answer = false; 
}
echo json_encode($answer);
exit;
