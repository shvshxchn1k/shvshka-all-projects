<?php
require_once '../../config/db_connect.php';
require_once '../../config/session_start.php';
require_once '../../core/functions.php';
header('Content-Type: application/json; charset=utf-8');
// Получить "сырые" данные JSON
$json = file_get_contents('php://input');
$data = json_decode($json, true); 

$id_kit = $data['id'];
$kit = sql_select('id', $id_kit, 'kit', $connect);
if ($kit) {
    $status = ($kit['status'] == '1') ? '2' : '1';
    $set = [
        'status' => $status
    ];
    $where = [
        'id' => $id_kit
    ];
    $answer = sql_update($set, $where, 'kit', $connect);
} else {
    $answer = false;
}
echo json_encode($answer);
exit;