<?php
// Для класса Attr, тока я хз зачем он
use Dom\Attr;
// Для лучших подсказок ide
use function PHPSTORM_META\type;


// проверяет доступ пользователя к коллекции
function check_user ($id_collection, $connect) {
    if (!empty($_SESSION['user'])) {
        $user = $_SESSION['user'];
        $collection = sql_select('id', $id_collection, 'collection', $connect)[0];
        if ($user['id'] == $collection['id_creator']) {
            $answer = true;
        } else {
            $answer['error'][1] = 'Данная коллекция принадлежит другому пользователю';
        }
    } else {
        $answer['error'][0] = 'Сначала войдите в аккаунт';
    }
    return $answer;
}

// делает SELECT в базу данных
// Принимает и массивы, и переменные
// Возрващает массив,
// Если в базе данных ничего не найдено вернет ошибку
function sql_select($key, $value, $table, $connect) {
    $table = "`$table`";
    $sql = "SELECT * FROM $table WHERE ";
    if (is_array($key) and is_array($value)) {
        $types = '';
        foreach ($key as $num => $value_param) {
            $types .= check_type($value[$num]);
            $sql .= "$value_param = ? and ";
        }
        $sql = mb_substr($sql, 0, -5);
        $sql .= ';';
    } elseif (!is_array($key) and !is_array($value)) {
        $sql .= "$key = ?;";
        $types = check_type($value);
    } else {
        alert_bootstrap_red('Неизвестная ошибка');
    }
    $stmt = $connect->prepare($sql);
    if (is_array($value)) {
        $stmt->bind_param($types, ...$value);
    } else {
        $stmt->bind_param($types, $value);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    if ($result->num_rows > 0) {
        $answer = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $answer['error'][0] = 'Нет совпадений в базе данных';
    }
    return $answer;
}

// Делaет INSERT в базу данных
function sql_insert($array, $table, $connect) {
    $table = "`$table`";
    $keys = [];
    $values = [];
    $types = '';
    $question_marks = '(';
    foreach ($array as $key => $value) {
        $keys[] = $key;
        $values[] = $value;
        $types .= check_type($value);
        $question_marks .= '?,';
    }
    $question_marks = mb_substr($question_marks, 0, -1);
    $question_marks .= ')';
    $binds = '(';
    foreach ($keys as $key) {
        $binds .= "$key, ";
    }
    $binds = mb_substr($binds, 0, -2);
    $binds .= ')';
    $stmt = $connect->prepare("INSERT INTO $table $binds VALUES $question_marks;");
    $stmt->bind_param($types, ...$values);
    $stmt->execute();
    $last_id = $connect->insert_id;
    $stmt->close();
    return $last_id;
}

// Обновляет данные в таблице
function sql_update ($set, $where, $table, $connect) {
    $table = "`$table`";
    $values_set = array_values($set);
    $keys_set = array_keys($set);
    $values_where = array_values($where);
    $keys_where = array_keys($where);
    if (count($set) > 1) {
        $request_set = '';
        $types_set = '';
        foreach($set as $key => $value) {
            $request_set .= "$key = ?, ";
            $types_set .= check_type($value);
        }
        $request_set = mb_substr($request_set, 0, -2);
    } else {
        $request_set = "$keys_set[0] = ?";
        $types_set = check_type($values_set[0]);
    }
    if (count($where) > 1) {
        $request_where = '';
        $types_where = '';
        foreach($where as $key => $value) {
            $types_where .= check_type($value);
            $request_where .= "$keys_where[$key] = ?, ";
        }
    } else {
        $types_where = check_type($values_where[0]);
        $request_where = "$keys_where[0] = ?";
    }
    $stmt = $connect->prepare("UPDATE $table SET $request_set WHERE $request_where;");
    $types = $types_set . $types_where;
    $stmt->bind_param($types, ...$values_set, ...$values_where);
    $stmt->execute();
    if ($stmt->affected_rows > 0) {
        $answer = true;
    } else {
        $answer = false;
    }
    return $answer;
}


// получает полную коллекцию, т.е категории, вопросы (Варианты ответов не получаем)
function get_collection($id_collection, $connect) {
    // Получаем данные коллекции
    $collection = sql_select('id', $id_collection, 'collection', $connect)[0];
    $answer['collection'] = $collection;
    // Получаем категории
    $categories = sql_select('id_collection', $id_collection, 'category', $connect);
    $answer['categories'] = $categories;
    // получаем вопросы
    $questions = [];
    foreach ($categories as $category) {
        $id_category = $category['id'];
        $array = sql_select('id_category', $id_category, 'question', $connect);
        $questions[$id_category] = $array;
    }
    $answer['questions'] = $questions;
    return $answer;
}

// проверяет созда ли была уже такая коллекция или еще нет
function check_create($key, $id_parent, $table, $connect) {
    $answer = sql_select($key, $id_parent, $table, $connect);
    if (!empty($answer['error'])) {
        if ($answer['error'][0]) {
            // т.к у нас ошибка "0" - не найдено ни одного совпадения, а нам это и нужно. то засчитываем это
            $answer = true;
        }
    } else {
        $answer = [];
        $answer['error'][0] = 'Уже создано';
    }
    return $answer;
}

// проверяет тип переменной
function check_type($value) {
    if (is_int($value)) {
        return 'i';
    }
    if (is_string($value)) {
        return 's';
    }
    if (is_double($value)) {
        return 'd';
    }
}
function clean_this($param) {
    if (is_string($param)) 
        $param = preg_replace('/\D/', '', $param);
    return $param;
}
// удаляет все символы кроме цифр и возвращает числом
function make_only_number ($param) {
    if (is_array($param)) {
        foreach ($param as $key => $value) {
            $param[$key] = clean_this($value);
        }
    } else {
        $param = clean_this($param);
    }
    return $param;
}

// Создает число нужной длинны
function create_number($len) {
    $number = '';
    for ($i = 1; $i <= $len; $i++) {
        $number .= mt_rand(1,9);
    }
    return intval($number);
}


// Выводит красиво массив
function dump_array($array) {
    echo '<pre>';
    print_r($array);
    echo '</pre>';
}

function br() {
    echo '<br>';
}

function clean_nickname ($nickname) {
    $nickname = preg_replace('/[^a-z0-9_]/', '', $nickname);
    return $nickname;
}

// Проверяет массив и/или переменную на запрещенные символы
function check_text($array, $forbidden_characters) {
    if (is_array($array)) {
        foreach ($array as $array_num => $array_symbol) {
            $array[$array_num] = verification_of_validity($array_symbol, $forbidden_characters);
        }
    } else {
        $array = verification_of_validity($array, $forbidden_characters);
    }
    return $array;
}

// останавливает код, если находит в нем запрещенные символы
function verification_of_validity($variable, $forbidden_characters) {
    $variable = trim($variable);
    foreach ($forbidden_characters as $forbidden_character) {
        if (str_contains($variable, $forbidden_character)) {
            alert_bootstrap_red('В строке есть недопустимый символ: ' . $forbidden_character);
            $variable = false;
        }
}
    return $variable;
}


// Заменяет кавычки, на кавычки "елочки"
function change_quotation_marks($variable) {
    $forbidden_characters = array('"', "'");
    foreach ($forbidden_characters as $forbidden_character) {
        if (str_contains($variable, $forbidden_character)) {
            $variable = explode($forbidden_character, $variable);
            $count = 1;
            $new_str = '';
            foreach ($variable as $key => $value) {
                if ($count == 1) {
                    $new_str .= $value . '«';
                    $count++;
                } else {
                    $new_str .= $value . '»';
                    $count = 1;
                }
            }
            $variable = mb_substr($new_str, 0, -1);
        }
    }
    return $variable;
}

function check_category($categories, $id) {
    foreach ($categories as $key => $category) {
        if ($category['id'] <= $id) {
            unset($categories[$key]);
        }
    }
    $categories = array_values($categories);
    return $categories;
}

function sql_check_length_db($table, $connect) {
    $table = mysqli_real_escape_string($connect, $table);
    $stmt = $connect->prepare("SELECT COUNT(*) AS total FROM `$table`");
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    $row = $result->fetch_assoc();
    return $row['total'];
}

// выводит красный алерт 
function alert_bootstrap_red($str) {
    echo '<div class="alert alert-danger" role="alert">' . $str . '</div>';
}

// выводит желтый алерт
function alert_bootstrap_yellow($str) {
    echo '<div class="alert alert-warning" role="alert">' . $str . '</div>';
}

// выводит зеленый алерт
function alert_bootstrap_green($str) {
    echo '<div class="alert alert-success" role="alert">' . $str . '</div>';
}

function alert_bootstrap_blue($str) {
    echo '<div class="alert alert-info" role="alert">' . $str . '</div>';
}