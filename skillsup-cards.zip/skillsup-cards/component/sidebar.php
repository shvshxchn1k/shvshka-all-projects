<link href="/css/sidebar.css" rel="stylesheet">
<div class="col-lg-3">
    <div class="filter-sidebar p-4 shadow-sm bg-body-tertiary" id="sidebar">
        <div class="filter-group">
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
            </form>
        </div>
        <div class="filter-group">
            <h6 class="mb-3">Игры</h6>
            <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" id="collection">
                <label class="form-check-label" for="electronics">
                    Коллекции
                </label>
            </div>
            <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" id="kit">
                <label class="form-check-label" for="clothing">
                    Наборы
                </label>
            </div>
            <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" id="profile">
                <label class="form-check-label" for="electronics">
                    Пользователи
                </label>
            </div>
        </div>

        <!-- <div class="filter-group">
            <h6 class="mb-3">Price Range</h6>
            <input type="range" class="form-range" min="0" max="1000" value="500">
            <div class="d-flex justify-content-between">
                <span class="text-muted">$0</span>
                <span class="text-muted">$1000</span>
            </div>
        </div> -->

        <!-- <div class="filter-group">
            <h6 class="mb-3">Colors</h6>
            <div class="d-flex gap-2">
                <div class="color-option selected" style="background: #000000;"></div>
                <div class="color-option" style="background: #dc2626;"></div>
                <div class="color-option" style="background: #2563eb;"></div>
                <div class="color-option" style="background: #16a34a;"></div>
            </div>
        </div> -->

        <!-- <div class="filter-group">
            <h6 class="mb-3">Rating</h6>
            <div class="form-check mb-2">
                <input class="form-check-input" type="radio" name="rating" id="rating4">
                <label class="form-check-label" for="rating4">
                    <i class="bi bi-star-fill text-warning"></i> 4 & above
                </label>
            </div>
            <div class="form-check mb-2">
                <input class="form-check-input" type="radio" name="rating" id="rating3">
                <label class="form-check-label" for="rating3">
                    <i class="bi bi-star-fill text-warning"></i> 3 & above
                </label>
            </div>
        </div> -->
        <!-- <button class="btn btn-outline-primary w-100">Apply Filters</button> -->
    </div>
</div>

<!-- Product Grid -->
<!-- <div class="col-lg-9">
    <div class="row g-4">
        Product Card 1
        <div class="col-md-4">
            <div class="product-card shadow-sm">
                <div class="position-relative">
                    <img src="https://via.placeholder.com/300x200" class="product-image w-100" alt="Product">
                    <span class="discount-badge">-20%</span>
                    <button class="wishlist-btn">
                        <i class="bi bi-heart"></i>
                    </button>
                </div>
                <div class="p-3">
                    <span class="category-badge mb-2 d-inline-block">Electronics</span>
                    <h6 class="mb-1">Wireless Headphones</h6>
                    <div class="rating-stars mb-2">
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-half"></i>
                        <span class="text-muted ms-2">(4.5)</span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="price">$129.99</span>
                        <button class="btn cart-btn">
                            <i class="bi bi-cart-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        Product Card 2
        <div class="col-md-4">
            <div class="product-card shadow-sm">
                <div class="position-relative">
                    <img src="https://via.placeholder.com/300x200" class="product-image w-100" alt="Product">
                    <button class="wishlist-btn">
                        <i class="bi bi-heart"></i>
                    </button>
                </div>
                <div class="p-3">
                    <span class="category-badge mb-2 d-inline-block">Electronics</span>
                    <h6 class="mb-1">Smart Watch Pro</h6>
                    <div class="rating-stars mb-2">
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star"></i>
                        <span class="text-muted ms-2">(4.0)</span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="price">$299.99</span>
                        <button class="btn cart-btn">
                            <i class="bi bi-cart-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        Product Card 3
        <div class="col-md-4">
            <div class="product-card shadow-sm">
                <div class="position-relative">
                    <img src="https://via.placeholder.com/300x200" class="product-image w-100" alt="Product">
                    <span class="discount-badge">-15%</span>
                    <button class="wishlist-btn">
                        <i class="bi bi-heart"></i>
                    </button>
                </div>
                <div class="p-3">
                    <span class="category-badge mb-2 d-inline-block">Accessories</span>
                    <h6 class="mb-1">Leather Wallet</h6>
                    <div class="rating-stars mb-2">
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-fill"></i>
                        <i class="bi bi-star-fill"></i>
                        <span class="text-muted ms-2">(5.0)</span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="price">$59.99</span>
                        <button class="btn cart-btn">
                            <i class="bi bi-cart-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->