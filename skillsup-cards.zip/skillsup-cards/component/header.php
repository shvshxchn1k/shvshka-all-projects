<?php $join_url = 'room/join/'; 
$join_button = '<li class="nav-item"><a class="nav-link" aria-current="page" href="' . htmlspecialchars($join_url) . '">Присоединится</a></li>';
?>
<nav id="header" style="min-height: 100px; z-index: 1000;" class="navbar navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
    <div class="container">
        <a class="navbar-brand logo" href="/main">
            <img src="/image/site/logo.png" alt="logo" class="logo" id="logo">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <?php if (!empty($_SESSION)) { ?>
                    <li class="nav-item"><a class="nav-link" aria-current="page" href="/collection/list/">Мои коллекции</a></li>
                    <li class="nav-item"><a class="nav-link" aria-current="page" href="/kit/list/">Мои наборы</a></li>
                    <li class="nav-item"><a class="nav-link" aria-current="page" href="/user/profile/<?php echo htmlspecialchars($_SESSION['user']['nickname']); ?>">Мой профиль</a></li>
                    <?php echo $join_button; ?>
                    <li class="nav-item"><a class="nav-link" aria-current="page" href="/user/logout/">Выйти</a></li>
                <?php } else { 
                    $join_url .= 'join';
                    echo $join_button
                    ?>
                    <li class="nav-item"><a class="nav-link" href="/user/login/">Войти</a></li>
                <?php } ?>
                
            </ul>
        </div>
    </div>
</nav>
