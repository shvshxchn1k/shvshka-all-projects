<?php
alert_bootstrap_red('Post не пришел на данную страницу');
echo '<a href="/main" class="btn btn-primary">На главную</a>';