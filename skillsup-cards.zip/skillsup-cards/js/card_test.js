const buttonsTestAnswer = document.querySelectorAll('.button-meaning');
let answerInputHidden;
let cardArea;
let cardAreaId;
let meaningArea;
let checkExistedAnswer;
let buttonClasses;
let allAnswerButtons;
buttonsTestAnswer.forEach(buttonTestAnswer => {
    buttonTestAnswer.addEventListener('click', (e) => {
        cardArea = buttonTestAnswer.parentElement;
        meaningArea = cardArea.parentElement;
        cardArea = meaningArea.parentElement;
        allAnswerButtons = meaningArea.querySelectorAll('.button-meaning');
        allAnswerButtons.forEach(answerButton => {
            answerButton.classList.remove('active', 'btn-primary');
            answerButton.classList.add('btn-secondary');
        });
        cardAreaId = cardArea.id.split('[')[1].slice(0, -1);
        answerInputHidden = document.getElementById('meaning[' + cardAreaId + ']');
        buttonTestAnswer.classList.remove('btn-secondary');
        buttonTestAnswer.classList.add('btn-primary', 'active');
        answerInputHidden.value = buttonTestAnswer.textContent.trim();
    });
});
