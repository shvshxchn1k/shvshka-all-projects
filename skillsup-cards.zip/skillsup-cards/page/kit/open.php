<link type="text/css" href="/css/card.css" rel="stylesheet">
<?php
$id_kit = $navs[2];
$kit = sql_select('id', $id_kit, 'kit', $connect)[0];
$cards = sql_select('id_kit', $kit['id'], 'card', $connect);
echo '<h1>Название набора: <span class="text-info">' . htmlspecialchars($kit['name']) . '</span></h1>';
if (!empty($kit['description'])) echo '<h4>Описание: ' . htmlspecialchars($kit['description']) . '</h4>';
?>

<div class="flip-card-container">
    <div class="flip-card" id="flipCard">
        <div class="flip-card-front bg-body-tertiary" id="cardFront"></div>
        <div class="flip-card-back bg-body-tertiary" id="cardBack"></div>
    </div>
</div>
<div class="controls">
    <button class="nav-btn" id="prevBtn">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="15 18 9 12 15 6"></polyline>
        </svg>
    </button>
    <div class="card-info">
        <p id="cardCounter">Карточка 1 из 5</p>
        <div class="progress-dots" id="progressDots"></div>
    </div>

    <button class="nav-btn" id="nextBtn">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 18 15 12 9 6"></polyline>
        </svg>
    </button>
</div>
<br>
<div class="row">
    <?php
    echo '<a href="/kit/edit/' . htmlspecialchars(make_only_number($id_kit)) . '" class="col btn btn-success">Редактировать</a>';
    ?>
    <a href="/kit/list" class="col btn btn-primary">К списку карточек</a>
</div>
<script> const CARDS = <?php echo json_encode($cards); ?></script>
<script src="/js/card.js" type="module"></script>