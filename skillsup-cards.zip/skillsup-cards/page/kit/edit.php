<link href="/css/card-edit.css" rel="stylesheet">
<?php
$id_kit = $navs[2];
$kit = sql_select('id', $id_kit, 'kit', $connect)[0];
$placeholder_description = (empty($kit['description'])) ? 'Здесь пусто! Попробуйте задать описание для вашего набора' : 'Описание набора';
$status = ($kit['status'] == '1') ? 'Только вам' : 'Всем';
$cards = sql_select('id_kit', $kit['id'], 'card', $connect);
echo '<h1>Редактирование набора: <span class="text-info">' . htmlspecialchars($kit['name']) . '</span></h1>';
$i = 1;
?>
<form action="/kit/update/<?php echo htmlspecialchars($id_kit) ?>" method="post">
    <input type="submit" class="btn btn-success" value="Сохранить">
    <button type="button" class="btn btn-primary" id="settings-button">Натройки</button>
    <div>
        <label for="description" class="form-label"><h2>Описание:</h2></label>
        <input type="text" class="form-control" id="description" name="description" placeholder="<?php echo htmlspecialchars($placeholder_description) ?>" value="<?php if (!empty($kit['description'])) echo htmlspecialchars($kit['description']) ?>">
    </div>
    <table class="table">
        <thead>
            <th scope="col">#</th>
            <th scope="col">Слово</th>
            <th scope="col">Значение/Перевод слова</th>
            <th scope="col"></th>
        </thead>
        <tbody id="card-table">
        <?php
        foreach ($cards as $card) {
            if ($card['status'] == '1') {
            ?>
                <tr id="row-<?php echo htmlspecialchars($card['id']) ?>">
                    <th scope="row"><?php echo $i; ?></th>
                    <td><input type="text" class="form-control" placeholder="Слово" name="word[<?php echo htmlspecialchars($card['id']) ?>][name]" value="<?php echo htmlspecialchars($card['name']); ?>" required></td>
                    <td><input type="text" class="form-control" placeholder="Значение/Перевод слова" name="word[<?php echo htmlspecialchars($card['id']) ?>][meaning]" value="<?php echo htmlspecialchars($card['meaning']); ?>" required></td>
                    <td><button class="btn btn-danger btn-delete-card" type="button" id="button-<?php echo htmlspecialchars($card['id']) ?>">Удалить</button></td>
                </tr>
            <?php
                $i++;
            }
        }
    ?>
        </tbody>    
    </table>
</form>
<div class="justify-content-center align-items-center" id="blocker">
    <div id="settings-window" class="bg-body-tertiary d-flex container">
        <h1>Настройки</h1>
        <div id="cards-settings-list" class="d-flex">
            <div class="row-window-settings">
                <span>Видно:</span>
                <button type="button" class="btn btn-secondary" id="button-privacy"><?php echo htmlspecialchars($status); ?></button>
            </div>
            <hr>
        </div>
        <div class="footer-window">
            <button class="btn btn-danger">Удалить набор</button>
        </div>
    </div>
</div>
<script type="module" src="/js/card_update.js"></script>