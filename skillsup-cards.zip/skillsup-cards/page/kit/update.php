<?php
$id_kit = $navs[2];
$kit = sql_select('id', $id_kit, 'kit', $connect)[0];
if ($kit['description'] != $_POST['description']) {
    $set = [
        'description' => $_POST['description']
    ];
    $where = [
        'id' => $id_kit
    ];
    $answer_description = sql_update($set, $where, 'kit', $connect);
}
$words = $_POST['word'];
$cards = sql_select('id_kit', $id_kit, 'card', $connect);
foreach ($cards as $card) {
    foreach ($words as $key => $word) {
        if ($card['id'] == $key) {
            if ($card['name'] != $word['name'] or $card['meaning'] != $word['meaning']) {
                $where = [
                    'id' => $card['id']
                ];
                sql_update($word, $where, 'card', $connect);
            }
        }
    }
}
echo '<meta http-equiv="refresh" content="0;URL=/kit/open/' . htmlspecialchars($id_kit) . '"/>';
