<style>
    #avatar_old {
        width: 150px;
        border-radius: 10px;
    }
</style>
<?php
if ($_POST) {
    $id_user = $_SESSION['user']['id'];
    if ($_FILES['avatar']['name']) {
        $target_dir = 'image/user/';
        $tmpName = $_FILES['avatar']['tmp_name'];
        $extension_file = explode('.', $_FILES['avatar']['name']);
        $extension_file = end($extension_file);
        $allowed_extensions = array('png', 'jpg', 'jpeg', 'webp', 'gif');
        if (in_array($extension_file, $allowed_extensions)) {
            $new_name = $id_user . '.' . $extension_file;
            $target_file = $target_dir . $new_name;
            if ($_FILES['avatar']['size'] <= 3000000) {
                foreach ($allowed_extensions as $allowed_extension) {
                    $path = 'image/user/' . $id_user . '.' . $allowed_extension;
                    if (file_exists($path)) {
                        unlink($path);
                    }
                }
                $target_file = trim($target_file);
                if (move_uploaded_file($tmpName, $target_file)) {
                    $_SESSION['user']['avatar'] = $new_name;
                    $sql = "UPDATE `user` SET `avatar` = '$new_name' WHERE `id` = $id_user;";
                    $result = $connect->query($sql);
                    if ($result) {
                        alert_bootstrap_green('Новая аватарка профиля успешно сохранена');
                    }
                } else {
                    alert_bootstrap_red('Произошла неизвестная ошибка при сохранении файла. Попробуйте еще раз');
                }
            } else {
                alert_bootstrap_red('Файл не может быть больше 3Мб. Попробуйте снова');
            }
        } else {
            $allowed_extensions_str = '';
            foreach ($allowed_extensions as $allowed_extension) {
                $allowed_extensions_str .= ' ' . $allowed_extension . ',';
            }
            $allowed_extensions_str = mb_substr($allowed_extensions_str, 0, -1);
            alert_bootstrap_red('Файл не подходящего расширения! Принимаются только файлы форматов:' . $allowed_extensions_str);
        }
    }
    // Проверка на обновление никнейма
    $banned_signs1 = array('"', "'", '|', '<', '>', '*', '(', ')', '!', '@', '«' , '»', '?');
    $nickname_new = check_text($_POST['nickname'], $banned_signs1);
    $nickname = $_SESSION['user']['nickname'];
    $sql = "SELECT * FROM `user` WHERE `nickname` = '$nickname';";
    $result = sql_select('nickname', $nickname, 'user', $connect);
    $user = $result->fetch_assoc();
    if ($nickname != $nickname_new) {
        $sql = "UPDATE `user` SET `nickname` = '$nickname_new' WHERE `id` = $id_user;";
        $result = $connect->query($sql);
        $_SESSION['user']['nickname'] = $nickname_new;
        alert_bootstrap_green('Новый никнейм успешно сохранен');
    }
    $banned_signs2 = array('|', '<', '>', '*',);
    $description_new = check_text($_POST['description'], $banned_signs2);
    $description_new = change_quotation_marks($description_new);
    if ($description_new != $_SESSION['user']['description']) {
        $sql = "UPDATE `user` SET `description` = '$description_new' WHERE `id` = $id_user;";
        $result = $connect->query($sql);
        alert_bootstrap_green('Новое описание успешно сохранено');
        $_SESSION['user']['description'] = $description_new;
    }
}
?>
<form action="" method="post" enctype="multipart/form-data">
    <div class="card">
        <img src="
            <?php
        if (empty($_SESSION['user']['avatar'])) {
            echo '/image/user/main_default.jpg';
        } else {
            echo '/image/user/' . $_SESSION['user']['avatar'];
        }
        ?>
        " class="card-img-top" id="avatar_old" alt="Автарка пользователя">
        <label for="avatar">Выберите новое фото профиля:</label>
        <input type="file" class="form-control" id="avatar" name="avatar" accept=".jpg, .jpeg, .png, .gif, .webp">
        <div class="card-body">
            <label for="nickname" class="form-label">Никнейм:</label>
            <h5 class="card-title">
                <input type="text" class="form-control" id="nickname" name="nickname" value="<?php echo $_SESSION['user']['nickname'] ?>"></h5>
            <p class="card-text">
                <label for="description" class="form-label">Описание:</label>
                <input type="text" class="form-control" id="description" name="description" value="<?php echo $_SESSION['user']['description'] ?>">
            </p>
        </div>
    </div>
    <?php
        alert_bootstrap_yellow('Для никнейма запрещены символы: | < > * ( ) ! @ ? « » " ' . "'");
    ?>
    <div class="container text-center">
        <div class="row align-items-start">
            <div class="col">
                <button type="submit" class="btn btn-primary">Сохранить</button>
            </div>
            <div class="col">
                <a href="/user/profile/<?php echo $_SESSION['user']['nickname'] ?>" class="btn btn-danger">Отменить</a>
            </div>
        </div>
    </div>
</form>

