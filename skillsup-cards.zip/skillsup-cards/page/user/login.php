<?php
if (!empty($navs[2])) {
    if ($navs[2] == 'join') {
        alert_bootstrap_yellow('Для того, чтобы принять участие в игре, сначала войдите или зарегистрируйтесь.');
    }
}
?>
<form method="post" action="">
    <div class="mb-3">
        <label for="email" class="form-label">Электронная почта:</label>
        <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name="email" placeholder="Введите вашу электронную почту" required>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Пароль:</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Введите ваш пароль" required>
    </div>
    <button type="submit" class="btn btn-success">Войти</button>
</form>
<br>
<h2>Нет учетной записи?</h2>
<a href="/user/register/" class="btn btn-primary">Зарегистрироваться</a>
<?php
if ($_POST) {
    $user_data = $_POST;
    $keys = array_keys($user_data);
    $values = array_values($user_data);
    $user = sql_select($keys, $values, 'user', $connect)[0];
    if ($user) {
        $_SESSION['user'] = $user;
        echo '<meta http-equiv="refresh" content="0;URL=/user/profile/' .  htmlspecialchars($_SESSION['user']['nickname']) . '"/>';
    } else {
        alert_bootstrap_red('Не подошла почта или пароль');
    }
}