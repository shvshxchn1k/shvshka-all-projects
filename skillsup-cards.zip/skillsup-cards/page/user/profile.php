<style>
    #avatar {
        width: 150px;
        border-radius: 10px;
    }
</style>
<link href="/css/profile.css" rel="stylesheet">
<?php
    $nickname = clean_nickname($navs[2]);
    $user = sql_select('nickname', $nickname, 'user', $connect)[0];
    if ($user) { 
        $kits = sql_select('id_creator', $user['id'], 'kit', $connect);
        $collections = sql_select('id_creator', $user['id'], 'collection', $connect);
    ?>
    <div class="card">
        <img src="
            <?php
                if (empty($user['avatar'])) {
                    echo '/image/user/main_default.jpg';
                } else {
                    echo '/image/user/' . htmlspecialchars($user['avatar']);
                }
            ?>
        " class="card-img-top" id="avatar" alt="">
        <div class="card-body">
            <h5 class="card-title"><?php echo htmlspecialchars($user['nickname']); ?></h5>
            <p class="card-text">
                <?php
                    if (empty($user['description'])) {
                        echo '<i>На данный момент здесь пусто...</i>';
                    } else {
                        echo htmlspecialchars($user['description']);
                    }
                 ?>
            </p>
        </div>
        <?php
        if (isset($_SESSION['user']['nickname'])) {
            if ($nickname == $_SESSION['user']['nickname']) {
                echo '<a href="/user/edit" class="btn btn-primary">Редактировать</a>';
            } else {
                echo '<a href="/user/" class="btn btn-primary">Подписаться</a>';
            }
        }
        ?>
    </div>
    <h2>Наборы:</h2>
    <div class="public-items-area d-flex">
        <?php
        if ($kits) {
            $i = 0;
            foreach ($kits as $kit) { 
                if ($kit['status'] == '2') {
                if ($i / 3 == 0) echo '</div><div class="public-items-row d-flex">';
                $kit_description = $kit['description'] ?? 'Пока что здесь пусто';
                ?>
            <div class="card">
                    <div class="card-title"><h4><?php echo htmlspecialchars($kit['name']); ?></h4></div>
                    <div class="card-text"><?php echo htmlspecialchars($kit_description); ?></div>
            </div>
                    <?php   
                    $i++;
                }
            }
        } 
    ?>
    </div>
    <?php
} else {
    require_once 'page/404.php';
    alert_bootstrap_yellow('Такого пользователя не существует');
}


