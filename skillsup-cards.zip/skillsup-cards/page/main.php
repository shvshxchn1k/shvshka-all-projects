<link rel="stylesheet" href="/css/main.css">
<?php
if (isset($_SESSION['user'])) {
    $url = '/room/join/';
} else {
    $url = '/user/login/join';
}
?>
<div id="main-content">
<?php
require_once 'component/sidebar.php';

?>
<div id="items-content ml-3">
    
</div>
<script type="module" src="/js/main.js"></script>
