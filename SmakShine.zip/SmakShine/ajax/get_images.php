<?php
include '../../config/db_connect.php';
header('Content-Type: application/json; charset=utf-8');