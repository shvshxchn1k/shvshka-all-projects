const burgerButton = document.getElementById('burgerButton');
const blocker = document.getElementById('blocker');

burgerButton.addEventListener('click', (event) => {
    if (blocker.style.display == 'block') {
        blocker.style.display = 'none';
    } else {
        blocker.style.display = 'block';
    }
});