import PhotoSwipeLightbox from '../libs/PhotoSwipe/photoswipe-lightbox.esm.min.js'
const lightbox = new PhotoSwipeLightbox({
   gallery: '#pictures',
    children: '.image',
    pswpModule: () => import('../libs/PhotoSwipe/photoswipe.esm.min.js')
});
lightbox.init();