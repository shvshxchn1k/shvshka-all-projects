const infinityScrollStrips = document.getElementsByClassName('infinityScrollStrip');
const windowInnerWidth = window.innerWidth;
const images = ['image1', 'image2', 'image3', 'image4', 'image5'];

let imagesSeasons = [];
Array.from(infinityScrollStrips).forEach(infinityScrollStrip => {
    Array.from(images).forEach(image => {
        let infinityScrollBlock = document.createElement('div');
        infinityScrollBlock.classList.add('infinityScrollBlock');
        infinityScrollBlock.style.backgroundImage = "url(images/main/blocks/" + image + ".png)";
        infinityScrollStrip.appendChild(infinityScrollBlock);
    });


    let infinityScrollBlocks = Array.from(infinityScrollStrip.getElementsByClassName('infinityScrollBlock'));
    const blockWidth = infinityScrollBlocks[0].offsetWidth;
    const speed = parseFloat(infinityScrollStrip.dataset.speed) || 1;
    let countAll = infinityScrollBlocks.length;
    let count = 0;
    let infinityScrollStripWidth = infinityScrollStrip.scrollWidth;
    const lenOfRow = blockWidth * countAll;
    let double = Math.ceil(windowInnerWidth / lenOfRow);
    while (double > 0) {
        infinityScrollBlocks.forEach(infinityScrollBlock => {
            const clone = infinityScrollBlock.cloneNode(true);
            infinityScrollStrip.appendChild(clone);
        });
        infinityScrollBlocks = Array.from(infinityScrollStrip.getElementsByClassName('infinityScrollBlock'));
        countAll = infinityScrollBlocks.length;
        double--;
    }
    Array.from(infinityScrollBlocks).forEach(infinityScrollBlock => {
        infinityScrollBlock.style.left = blockWidth * count + 'px';
        count++;
    });
    blocks();
    function blocks() {
        let interval = setInterval(() => {
            Array.from(infinityScrollBlocks).forEach(infinityScrollBlock => {
                const direction = infinityScrollStrip.dataset.direction || 'right';
                let currentLeft = parseFloat(infinityScrollBlock.style.left);
                if (direction == 'right') {
                    let newLeft = currentLeft + speed;
                    if (newLeft > blockWidth * (countAll - 1)) {
                        newLeft = -blockWidth;
                    }
                    setLeft(infinityScrollBlock, newLeft);
                } else if (direction == 'left') {
                    let newLeft = currentLeft - speed;
                    if (newLeft < -blockWidth) {
                        newLeft += blockWidth * countAll;
                    }
                    setLeft(infinityScrollBlock, newLeft);
                }
                // infinityScrollStrip.addEventListener('mouseover', function (event) {
                //     clearInterval(interval);
                // });
            });
        }, 1);
    }
    // infinityScrollStrip.addEventListener('mouseout', function (event) {
    //     blocks();
    // });
});
function setLeft (element, value) {
    element.style.left = value + 'px';
}

const infoLogo = document.getElementsByClassName('container-info-logo');
infoLogo[0].addEventListener('mousemove', e => {
    const blockWidth = infoLogo[0].offsetWidth;
    const blockHeight = 320;
    Object.assign(infoLogo[0], {
        style: `
        --move-x: ${(e.clientX - blockWidth / 2) * 0.03}deg;
        --move-y: ${(e.clientY - blockHeight / 2) * 0.03}deg;
        transition: 0.2s all;
        `
    });
});
infoLogo[0].addEventListener('mouseout', e => {
    Object.assign(infoLogo[0], {
        style: `
        --move-x: 0deg;
        --move-y: 0deg;
        transition: 2s all;
        `
    });
});