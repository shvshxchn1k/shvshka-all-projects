-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 26 2024 г., 13:58
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `SmakShine`
--

-- --------------------------------------------------------

--
-- Структура таблицы `passwords`
--

CREATE TABLE `passwords` (
  `id` int NOT NULL,
  `nickname` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `passwords`
--

INSERT INTO `passwords` (`id`, `nickname`, `email`, `password`) VALUES
(1, 'nu', 'makyak09@gmail.com', '%gHggdD174GGds._*3FFssd'),
(2, 'gim_god_gamarus', 'smakshine@gmail.com', 'I2+2RVlSHn$R+8r!ZDfG1KfjPPXiH2');

-- --------------------------------------------------------

--
-- Структура таблицы `seasons`
--

CREATE TABLE `seasons` (
  `id` int NOT NULL,
  `name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `description` varchar(1000) NOT NULL,
  `in_header` varchar(200) NOT NULL,
  `status` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `seasons`
--

INSERT INTO `seasons` (`id`, `name`, `description`, `in_header`, `status`) VALUES
(1, 'Сезон 1', 'Сезон - начало новой эпохи. Эпохи великого Smak Shine', 'fa-solid fa-ship. Первый', '1'),
(2, 'Сезон 2', 'Развитие, развитие и ещё раз развитие. Сезон судьбоносных решений сервера', 'fa-solid fa-leaf. Второй', '1'),
(3, 'Сезон 3', 'Самый ламповый сезон - развитие РП, взаимоотношений и построек на сервере', 'fa-solid fa-ticket. Третий', '1'),
(4, 'Сезон 4', 'Петербуржский спаун, огромные статуи и постройки', 'fa-solid fa-globe. Четвертый', '1'),
(5, 'Сезон 5', 'Сезон просада всех сфер жизни, объединение с другим сервером и большие проблемы', 'fa-solid fa-tree. Пятый', '0'),
(6, 'Сезон 6', 'Нынешний сезон', 'fa-solid fa-compass. Шестой', '0');

-- --------------------------------------------------------

--
-- Структура таблицы `seasons_images`
--

CREATE TABLE `seasons_images` (
  `id` int NOT NULL,
  `id_season` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `image` varchar(200) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `status` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `seasons_images`
--

INSERT INTO `seasons_images` (`id`, `id_season`, `image`, `description`, `status`) VALUES
(1, 'Сезон 1', 'season1/image1.png', 'Был дом, стоял в поле111', 1),
(2, 'Сезон 1', 'season1/image2.png', 'был, тоже дом, стоял в поле', 1),
(3, 'Сезон 2', 'season2/image1.png', 'Стоиииит дом', 1),
(4, 'Сезон 3', 'season3/image1.png', 'Арена. Сооружение которое было чуть ли не самым большим на спавне. В планах было множество событий связанных с ней, но им к сожалению не суждено было сбыться. Там так и не прошло ни одного боя, но сколько было надежд.', 1),
(5, 'Сезон 4', 'season4/image1.png', 'апвипиапти', 1),
(6, 'Сезон 1', 'season1/image3.png', 'домммммммммммммммм', 1),
(7, 'Сезон 1', 'season1/image4.png', 'домммммммммммиииииик', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `passwords`
--
ALTER TABLE `passwords`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `seasons`
--
ALTER TABLE `seasons`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `seasons_images`
--
ALTER TABLE `seasons_images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `passwords`
--
ALTER TABLE `passwords`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `seasons`
--
ALTER TABLE `seasons`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `seasons_images`
--
ALTER TABLE `seasons_images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
