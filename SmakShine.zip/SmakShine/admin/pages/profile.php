<link rel="stylesheet" href="css/profile.css">
<section class="profile">
    <header><h1><?php echo $_SESSION['nickname']; ?></h1></header>
    <div class="email"><h3><?php echo $_SESSION['email']; ?></h3></div>
    <div class="status">
        <h3>Ваш код доступа: <?php
            if ($_SESSION['status'] == 1) {
                echo $_SESSION['status'] . ' (Администратор)';
            } elseif ($_SESSION['status'] == 2) {
                echo $_SESSION['status'] . ' (Модератор)';
            } elseif ($_SESSION['status'] == 3) {
                echo $_SESSION['status'] . ' (Хелпер)';
            }
            ?>
        </h3>
    </div>
</section>