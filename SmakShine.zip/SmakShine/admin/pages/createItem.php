<form action="" method="post">
    <div class="mb-3">
        <label for="category" class="form-label">Категория:</label>
        <input type="text" class="form-control" id="category" name="category" placeholder="Категория">
        <label for="category" class="form-text">Название категории (на английскойм: services | sets | subscription | other)</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="name" class="form-label">Наименование товара:</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Наименование товара">
        <label for="name" class="form-text">Наименование товара</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="price" class="form-label">Цена товара:</label>
        <input type="text" class="form-control" id="price" name="price" placeholder="Цена товара">
        <label for="price" class="form-text">Цена (комиссия)</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="image" class="form-label">Адрес картинки:</label>
        <input type="text" class="form-control" id="image" name="image" placeholder="Адрес картинки">
        <label for="image" class="form-text">Категория/Картинка.png(Пример: services/image1.png)</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="description" class="form-label">Описание товара:</label>
        <input type="text" class="form-control" id="description" name="description" placeholder="Описание товара">
        <label for="description" class="form-text">Описание товара</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="status" class="form-label">Статус:</label>
        <input type="number" class="form-control" id="status" name="status" placeholder="1 (активен) или 0 (неактивен)">
        <label for="status" class="form-text">1 (активен) или 0 (неактивен)</label>
    </div>
    <hr>
    <button type="submit" class="btn btn-primary">Сохранить</button>
</form>
<?php
if ($_POST) {
    echo $image = $_POST['image'];
    echo '<br>';
    echo $category = $_POST['category'];
    echo '<br>';
    echo $name = $_POST['name'];
    echo '<br>';
    $sql = "SELECT * FROM `shop` WHERE `image` = '$image' AND `category` = '$category' AND `name` = '$name';";
    $result = $connect->query($sql);
    if ($result->num_rows > 0) {
        echo '<h1>Такой товар уже существует</h1>';
    } else {
        $forbiddenCharacters = array("'", '<', '>','*', '|', '#', '"');
        $array = checkArray($_POST, $forbiddenCharacters);
        if ($array != NULL) {
            $table = 'shop';
            saveInTable($table, $connect);
            echo '<meta http-equiv="refresh" content="2 url=?go=seasons" />';
        }
    }
}
?>
<script src="js/createItem.js"></script>