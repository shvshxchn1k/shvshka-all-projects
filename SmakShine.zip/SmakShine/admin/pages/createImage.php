<link rel="stylesheet" href="css/createImage.css">
<form action="" method="post">
    <div class="mb-3">
        <label for="id_season" class="form-label">Айди сезона</label>
        <input type="text" class="form-control" id="id_season" name="id_season" placeholder="Айди сезона">
        <label for="id_season" class="form-text">Пример: Сезон n</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="image" class="form-label">Адрес картинки:</label>
        <input type="text" class="form-control" id="image" name="image" placeholder="Адрес картинки (исключительно на латинице)">
        <label for="image" class="form-text">Пример: season1/image5.png</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="description" class="form-label">Описание картинки:</label>
        <input type="text" class="form-control" id="description" name="description" placeholder="Напишите какое-нибудь маленькое описание">
    </div>
    <hr>
    <div class="mb-3">
        <label for="status" class="form-label">Статус:</label>
        <input type="number" class="form-control" id="status" name="status" placeholder="1 или 0">
        <label for="status" class="form-text">Укажите только цифру</label>
    </div>
    <hr>
    <button type="submit" class="btn btn-primary">Сохранить</button>
</form>
<?php
    if ($_POST) {
        $image = $_POST['image'];
        $id_season = $_POST['id_season'];
        echo $id_season;
        echo '<br>';
        echo $image;
        $sql = "SELECT * FROM `seasons_images` WHERE `image` = '$image' AND `id_season` = '$id_season';";
        $result = $connect->query($sql);
        if ($result->num_rows > 0) {
            echo '<h1>Такая картинка уже существует</h1>';
        } else {
            $forbiddenCharacters = array("'", '<', '>','*', '|', '#', '"');
            $array = checkArray($_POST, $forbiddenCharacters);
            if ($array != NULL) {
                $table = 'seasons_images';
                saveInTable($table, $connect);
            }
        }
    }
?>
<script src="js/createImage.js"></script>