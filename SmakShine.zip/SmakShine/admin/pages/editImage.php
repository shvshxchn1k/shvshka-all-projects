<?php
if ($_GET['id']) {
    $id = $_GET['id'];
    if (!$_POST) {
        $sql = "SELECT * FROM `seasons_images` WHERE `id` = '$id'";
        $result = $connect->query($sql);
        if ($result->num_rows == 0) {
            echo 'Ошибка: Такой картинки не существует';
        } else {
            $row = $result->fetch_assoc();
            $id_season = $row['id_season'];
            $image = $row['image'];
            $description = $row['description'];
            $status = $row['status'];
        }
    } else {
        $forbiddenCharacters = array("'", '<', '>','*', '|', '#',);
        $array = checkArray($_POST, $forbiddenCharacters);
        if ($array != NULL) {
            $table = 'seasons_images';
            updateInTable($table, $connect, $id);
            $id_season = $_POST['id_season'];
            $image = $_POST['image'];
            $description = $_POST['description'];
            $status = $_POST['status'];
        }
    }
} else {
    echo "Ошибка: параметр 'get' не задан";
}
?>
<form action=""  method="post">
    <div class="mb-3">
        <label for="id_season" class="form-label">Сезон:</label>
        <input type="text" class="form-control" id="id_season" name="id_season" value="<?php echo $id_season; ?>" placeholder="Сезон">
        <label for="id_season" class="form-text">Пример: Сезон 1</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="image" class="form-label">Адрес картинки:</label>
        <input type="text" class="form-control" id="image" name="image" value="<?php echo $image; ?>" placeholder="Адрес картинки (исключительно на латинице)">
        <label for="image" class="form-text">Пример: season1/image5.png</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="description" class="form-label">Описание картинки:</label>
        <input type="text" class="form-control" id="description" name="description" value="<?php echo $description; ?>" placeholder="Напишите какое-нибудь маленькое описание">
    </div>
    <hr>
    <div class="mb-3">
        <label for="status" class="form-label">Статус картинки</label>
        <input type="number" class="form-control" id="status" name="status" value="<?php echo $status; ?>" placeholder="1 или 0">
        <label for="image" class="form-text">1 (активна) или 0 (неактивна)</label>
    </div>
    <button type="submit" class="btn btn-primary">Редактировать</button>
</form>

<table class="table">
    <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Картинка</th>
            <th scope="col">Описание</th>
            <th scope="col">Статус</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th scope="row"><?php echo $id; ?></th>
            <td><?php echo $_POST['image']; ?></td>
            <td><?php echo $_POST['description']; ?></td>
            <td><?php echo $_POST['status']; ?></td>
        </tr>
    </tbody>
</table>
<script src="js/editImage.js"></script>