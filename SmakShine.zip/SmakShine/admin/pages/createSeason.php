<link rel="stylesheet" href="css/createSeason.css">
<form action="" method="post">
    <div class="mb-3">
        <label for="name" class="form-label">Айди сезона</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Айди сезона">
        <label for="name" class="form-text">Пример: Сезон n</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="description" class="form-label">Описание сезона:</label>
        <input type="text" class="form-control" id="description" name="description" placeholder="Напишите какое-нибудь маленькое описание">
    </div>
    <hr>
    <div class="mb-3">
        <label for="in_header" class="form-label">Сезон в меню:</label>
        <input type="text" class="form-control" id="in_header" name="in_header" placeholder="Сезон в шапке в меню">
    </div>
    <hr>
    <div class="mb-3">
        <label for="status" class="form-label">Статус:</label>
        <input type="text" class="form-control" id="status" name="status" placeholder="Статус">
        <label for="status" class="form-text">1 или 0</label>
    </div>
    <button type="submit" class="btn btn-primary">Сохранить</button>
</form>
<?php
if ($_POST) {
    $name = $_POST['name'];
    $in_header = $_POST['in_header'];
    $sql = "SELECT * FROM `seasons` WHERE `name` = '$name' AND `in_header` = '$in_header';";
    $result = $connect->query($sql);
    if ($result->num_rows > 0) {
        echo 'Такой сезон уже существует';
    } else {
        $forbiddenCharacters = array("'", '<', '>','*', '|', '#', '"',);
        $array = checkArray($_POST, $forbiddenCharacters);
        $table = 'seasons';
        saveInTable($table, $connect);
        echo '<meta http-equiv="refresh" content="url=?go=seasons" />';
    }
}
?>
<script src="js/createSeason.js"></script>
