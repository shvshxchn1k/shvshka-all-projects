<link rel="stylesheet" href="css/seasons.css">
    <?php
    $sql = 'SELECT * FROM `seasons`';
    $result = mysqli_query($connect, $sql);
    if ($result == false) {
        print("Произошла ошибка при выполнении запроса");
    } else {
        while ($row = mysqli_fetch_array($result)) {
            $data[] = $row;
        }
        ?>
        <table class="table">
            <thead>
            <tr>
                <th scope="col">id</th>
                <th scope="col">Сезон</th>
                <th scope="col">Описание</th>
                <th scope="col">В меню</th>
                <th scope="col">Статус</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($data as $row) {
                $row['in_header'] = explode(".", $row['in_header']);
                echo '<tr>';
                echo '<th scope="row">' . $row['id'] . '</th>';
                echo '<td><a href="?go=seasonImages&sub=' . $row['id'] . '" class="text-decoration-none">' . $row['name'] . '</a></td>';
                echo '<td>' . $row['description'] . '</td>';
                echo '<td><i class="' . $row['in_header'][0] . '"</i>' . $row['in_header'][1] . '</td>';
                echo '<td>' . $row['status'] . '</td>';
                echo '<td><a href="?go=editSeason&id=' . $row['id'] . '"><button>Редактировать</button></a></td>';
                echo '</tr>';
            }
            ?>
            </tbody>
        </table>
        <a href="?go=createSeason"><button>Создать новый сезон</button></a>
    <?php
    }
    ?>

