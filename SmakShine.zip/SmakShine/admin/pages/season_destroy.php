<?php
session_destroy();
echo '<meta http-equiv="refresh" content="1 url=index.php" />';
