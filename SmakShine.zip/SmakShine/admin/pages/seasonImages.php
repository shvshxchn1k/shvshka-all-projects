<link rel="stylesheet" href="css/seasonImages.css">
<?php
    $seasonNum = $_GET['sub'];
    $season = 'Сезон ' . $seasonNum;

    $sql = 'SELECT * FROM `seasons_images`';
    $result = mysqli_query($connect, $sql);
    if ($result == false) {
        print("Произошла ошибка при выполнении запроса");
    } else {
        while ($row = mysqli_fetch_array($result)) {
            if ($row['id_season'] == $season) {
                $data[] = $row;
            }
        }
        ?>
        <table class="table">
            <thead>
            <tr>
                <th scope="col">id</th>
                <th scope="col">Картинка</th>
                <th scope="col">Описание</th>
                <th scope="col">Статус</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($data as $row) {
                echo '<tr>';
                echo '<th scope="row">' . $row['id'] . '</th>';
                echo '<td><img src="../images/seasons/' . $row['image'] . '"></td>';
                echo '<td>' . $row['description'] . '</td>';
                echo '<td>' . $row['status'] . '</td>';
                echo '<td><a href="?go=editImage&id=' . $row['id'] . '"><button>Редактировать</button></a></td>';
                echo '</tr>';
            }
            ?>
            </tbody>
        </table>
        <a href="?go=createImage"><button>Добавить новое фото</button></a>
    <?php
    }
?>

