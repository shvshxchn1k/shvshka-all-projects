<?php
if ($_GET['id']) {
    $id = $_GET['id'];
    if (!$_POST) {
        $sql = "SELECT * FROM `shop` WHERE `id` = '$id'";
        $result = $connect->query($sql);
        if ($result->num_rows == 0) {
            echo 'Ошибка: Такой картинки не существует';
        } else {
            $row = $result->fetch_assoc();
            $category = $row['category'];
            $name = $row['name'];
            $price = $row['price'];
            $image = $row['image'];
            $description = $row['description'];
            $status = $row['status'];
        }
    } else {
        $forbiddenCharacters = array("'", '<', '>','*', '|', '#',);
        $array = checkArray($_POST, $forbiddenCharacters);
        if ($array != NULL) {
            $table = 'shop';
            updateInTable($table, $connect, $id);
            $category = $_POST['category'];
            $name = $_POST['name'];
            $price = $_POST['price'];
            $image = $_POST['image'];
            $description = $_POST['description'];
            $status = $_POST['status'];
        }
    }
} else {
    echo "Ошибка:" . $_GET['id'] . "не задан";
}
?>
<form action=""  method="post">
    <div class="mb-3">
        <label for="category" class="form-label">Категория:</label>
        <input type="text" class="form-control" id="category" name="category" value="<?php echo $category; ?>" placeholder="Категория">
        <label for="category" class="form-text">Название категории (на английскойм)</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="name" class="form-label">Наименование товара:</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" placeholder="Наименование товара">
        <label for="name" class="form-text">Наименование товара</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="price" class="form-label">Цена товара:</label>
        <input type="text" class="form-control" id="price" name="price" value="<?php echo $price; ?>" placeholder="Цена товара">
        <label for="price" class="form-text">Цена (комиссия)</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="image" class="form-label">Адрес картинки:</label>
        <input type="text" class="form-control" id="image" name="image" value="<?php echo $image; ?>" placeholder="Адрес картинки">
        <label for="image" class="form-text">Категория/Картинка.png(Пример: services/image1.png)</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="description" class="form-label">Описание товара:</label>
        <input type="text" class="form-control" id="description" name="description" value="<?php echo $description; ?>" placeholder="Описание товара">
        <label for="description" class="form-text">Описание товара</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="status" class="form-label">Статус:</label>
        <input type="number" class="form-control" id="status" name="status" value="<?php echo $status; ?>" placeholder="1 (активен) или 0 (неактивен)">
        <label for="status" class="form-text">1 (активен) или 0 (неактивен)</label>
    </div>
    <hr>
    <button type="submit" class="btn btn-primary">Редактировать</button>
</form>
<script src="editItem.js"></script>
