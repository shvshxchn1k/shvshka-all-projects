<link rel="stylesheet" href="css/check.css">
<section class="check-page">
    <img src="images/smak_shine.png" alt="Лого"><h1>Smak Shine Admin</h1>
    <div class="form-container">
        <form action="" method="post">
            <div class="mb-3">
                <label for="id" class="form-label">id:</label>
                <input type="number" class="form-control" id="id" name="id" placeholder="Ваш id в системе">
                <label for="id" class="form-text">Укажите только цифру</label>
            </div>
            <hr>
            <div class="mb-3">
                <label for="nickname" class="form-label">nickname:</label>
                <input type="text" class="form-control" id="nickname" name="nickname" placeholder="Ваш никнейм в системе">
                <label for="nickname" class="form-text">Исключительно латиница</label>
            </div>
            <hr>
            <div class="mb-3">
                <label for="email" class="form-label">email:</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Ваша почта в системе">
                <label for="email" class="form-text">Исключительно латиница</label>
            </div>
            <hr>
            <div class="mb-3">
                <label for="password" class="form-label">password:</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Ваш пароль в системе">
                <label for="nickname" class="form-text">Исключительно латиница</label>
            </div>
            <button type="submit" class="btn btn-primary">Отправить на проверку шашке</button>
        </form>
    </div>
</section>
<?php
if ($_POST) {
    $forbiddenCharacters = array('<', '>', "'", '*');
    checkArray($_POST, $forbiddenCharacters);
    $id = $_POST['id'];
    $nickname = $_POST['nickname'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM `passwords` WHERE `id` = '$id' AND `nickname` = '$nickname' AND `email` = '$email' AND `password` = '$password'";
    $result = $connect->query($sql);
    dumpArray($result);
    if ($result == false) {
        echo 'Еще раз попробуй';
    } else {
        $row = $result->fetch_assoc();
        dumpArray($row);
        $_SESSION['nickname'] = $row['nickname'];
        echo 'Никнейм: ' . $row['nickname'];
        $_SESSION['status'] = $row['status'];
        echo 'Статус: ' . $row['status'];
        $_SESSION['email'] = $row['email'];
        echo '<br>';
        echo 'Никнейм в сессии: ' . $_SESSION['nickname'];
        echo '<br>';
        echo 'Проверка пройдена, пупсик';
        echo '<meta http-equiv="refresh" content="3 url=?go=profile" />';
    }
}
?>
<script src="js/check.js"></script>