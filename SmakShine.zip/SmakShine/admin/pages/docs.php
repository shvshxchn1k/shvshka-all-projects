<link rel="stylesheet" href="css/docs.css">
<?php
if ($_GET['sub']) {
    include 'components/docs_header.php';
    echo '<h2 style="display: flex; justify-content: center; color: red">Система гинерации картинок временно не раотает</h2>';
    $table = 'docs';
    if ($_GET['name']) {
        $name = $_GET['name'];
        $category = $_GET['sub'];
        $sql = "SELECT * FROM `$table` WHERE `category` = '$category' AND `name` = '$name';";
        $result = mysqli_query($connect, $sql);
        $row = $result->fetch_assoc();
        echo '<h1>' . $row['nameRu'] . '</h1>';
        echo '<hr>';
        $row['images'] = explode(' ', $row['images']);
        echo $row['text'];
    } else {
        $category = $_GET['sub'];
        $sql = "SELECT * FROM `$table` WHERE `category` = '$category';";
        $result = mysqli_query($connect, $sql);
        $data = [];
        while ($row = mysqli_fetch_array($result)) {
            $data[] = $row;
        }
        echo '<h2><a href="#" style="display: flex; justify-content: center; cursor: inherit" class="text-decoration-none">' . $category . '</a></h2>';
        ?>
        <table class="table">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Наименование</th>
                    <th>Name</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <?php
                    foreach ($data as $key => $row) {
                        echo '<th scope="col">' . $row['id'] . '</th>';
                        echo '<th scope="col"><a href="?go=docs&sub=' . $row['category'] . '&name=' . $row['name'] .'" class="text-decoration-none">' . $row['nameRu'] . '</a></th>';
                        echo '<th scope="col">' . $row['name'] . '</th>';
                    }
                    ?>
                </tr>
            </tbody>
        </table>
    <?php
    }
}
?>
