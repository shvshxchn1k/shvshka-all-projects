<?php
if ($_GET['id']) {
    $id = $_GET['id'];
    if (!$_POST) {
        $sql = "SELECT * FROM `seasons` WHERE `id` = '$id'";
        $result = $connect->query($sql);
        if ($result->num_rows == 0) {
            echo 'Ошибка: Такого сезона не существует';
        } else {
            $row = $result->fetch_assoc();
            $name = $row['name'];
            $description = $row['description'];
            $in_header = $row['in_header'];
            $status = $row['status'];
        }
    } else {
        $forbiddenCharacters = array("'", '<', '>','*', '|', '#',);
        $array = checkArray($_POST, $forbiddenCharacters);
        if ($array != NULL) {
            $table = 'seasons';
            updateInTable($table, $connect, $id);
            $name = $_POST['name'];
            $description = $_POST['description'];
            $in_header = $_POST['in_header'];
            $status = $_POST['status'];
        }
    }
} else {
    echo "Ошибка:" . $_GET['id'] . "не задан";
}
?>
<form action="" method="post">
    <div class="mb-3">
        <label for="name" class="form-label">Сезон:</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo $name ?>" placeholder="Сезон">
        <label for="name" class="form-text">Пример: Сезон 1</label>
    </div>
    <hr>
    <div class="mb-3">
        <label for="description" class="form-label">Описание сезона:</label>
        <input type="text" class="form-control" id="description" name="description" value="<?php echo $description ?>" placeholder="Напишите какое-нибудь маленькое описание">
    </div>
    <hr>
    <div class="mb-3">
        <label for="in_header" class="form-label">Сезон в меню:</label>
        <input type="text" class="form-control" id="in_header" name="in_header" value="<?php echo $in_header ?>" placeholder="Сезон в шапке в меню">
    </div>
    <hr>
    <div class="mb-3">
        <label for="status" class="form-label">Статус сезона:</label>
        <input type="number" class="form-control" id="status" name="status" value="<?php echo $status ?>" placeholder="1 или 0">
        <label for="name" class="form-text">1 (активен) или 0 (неактивен)</label>
    </div>
    <button type="submit" class="btn btn-primary">Редактировать</button>
</form>
<table class="table">
    <thead>
    <tr>
        <th scope="col">id</th>
        <th scope="col">Сезон</th>
        <th scope="col">Описание</th>
        <th scope="col">Сезон в меню</th>
        <th scope="col">Статус</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <th scope="row"><?php echo $id; ?></th>
        <td><?php echo $name; ?></td>
        <td><?php echo $description; ?></td>
        <?php
            $in_header = explode(".", $in_header);
            print_r($in_header);
            echo '<td><i class="' . $in_header[0] . '"</i>' . $in_header[1] . '</td>';
        ?>
        <td><?php echo $status; ?></td>
    </tr>
    </tbody>
</table>
<script src="js/editSeason.js"></script>