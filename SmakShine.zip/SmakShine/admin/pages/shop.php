<link rel="stylesheet" href="css/shop.css">
<?php include 'components/shop_header.php';
$category = $_GET['sub'];
$sql = "SELECT * FROM `shop` WHERE `category` = '$category'";
$result = mysqli_query($connect, $sql);
    if ($result == false) {
        print("Произошла ошибка при выполнении запроса");
    } else {
        while ($row = mysqli_fetch_array($result)) {
            $data[] = $row;
        }
    }
?>
<table class="table">
    <thead>
    <tr>
        <th scope="col">id</th>
        <th scope="col">Категория</th>
        <th scope="col">Наименование</th>
        <th scope="col">Цена</th>
        <th scope="col">Картинка</th>
        <th scope="col">Описание</th>
        <th scope="col">Статус</th>
        <th scope="col"></th>
    </tr>
    </thead>
    <tbody>
    <?php
        foreach ($data as $row) {
            echo '<tr>';
            echo '<th scope="row">' . $row['id'] . '</th>';
            echo '<td>' . $row['category'] . '</td>';
            echo '<td>' . $row['name'] . '</td>';
            echo '<td>' . $row['price'] . '</td>';
            echo '<td><img src="../images/shop/' . $row['image'] . '"></td>';
            echo '<td>' . $row['description'] . '</td>';
            echo '<td>' . $row['status'] . '</td>';
            echo '<td><a href="?go=editItem&id=' . $row['id'] . '"><button>Редактировать</button></a></td>';
            echo '</tr>';
        }
    ?>
    </tbody>
</table>
<a href="?go=createItem"><button>Создать новый товар</button></a>