<?php
if ($_SERVER['HTTP_HOST'] == 'smakshine') {
    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'SmakShine';
} elseif ($_SERVER['HTTP_HOST'] == 'site.smakshine.com') {
    $servername = 'localhost';
    $username = 'l98506b4_smak';
    $password = 'LQ4zaTjg!jn6d_7';
    $dbname = 'l98506b4_smak';
}
//$servername = 'mysql.lifehosting.ru:3306';
//$username = 'u3535_XsMaM8S4BZ';
//$password = '^Jx0q.GVH16Uppqm8iBp+LM+';
//$dbname = 's3535_database_testing';
$connect = new mysqli($servername, $username, $password, $dbname);
if ($connect->connect_error) {
    die("Ошибка базы данных: " . $connect->connect_error);
}