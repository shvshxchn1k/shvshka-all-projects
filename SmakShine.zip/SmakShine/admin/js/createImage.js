checkInput('input[id="image"]', /[а-яё<>|А-ЯЁ*A-Z()@]/);
checkInput('input[id="description"]', /[<>|/A-Za-z()@]/);
checkInputEmpty();
