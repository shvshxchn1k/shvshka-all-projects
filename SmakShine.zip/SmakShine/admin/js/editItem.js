checkInput('input[id="category"]', /[а-яё<>|А-ЯЁ*A-Z()@/.,'"]/);
checkInput('input[id="name"]', /[a-z<>|A-Z*()@/'"]/);
checkInput('input[id="price"]', /[a-z<>|A-Z*@А-Я/'"]/);
checkInput('input[id="image"]', /[а-я<>|А-Я*@(),'"]/);
checkInput('input[id="description"]', /[a-z<>|A-Z*@]/);
checkInputEmpty();