checkInput('input[id="name"]', /[<>|/A-Za-z()@.,]/)
checkInput('input[id="description"]', /[<>|/A-Za-z()@]/);
checkInput('input[id="in_header"]', /[<>|/A-Z()@]/);
checkInputEmpty();
