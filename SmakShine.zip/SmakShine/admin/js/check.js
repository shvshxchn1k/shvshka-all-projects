checkInput('input[type="text"]', /[а-яё<>|А-ЯЁ*A-Z/.,$@()-]/);
checkInput('input[type="email"]', /[а-яё<>|А-ЯЁ*/,$()]/);
checkInput('input[type="password"]', /[а-яё<>А-ЯЁ*/,]/);
checkInputEmpty();
