checkInput('input[id="image"]', /[а-яё<>|А-ЯЁ*A-Z()@]/);
checkInput('input[id="description"]', /[<>|/A-Za-z()@]/);
checkInput('input[id="id_season"]', /[<>|/A-Za-z(),.@]/);
checkInputEmpty();
