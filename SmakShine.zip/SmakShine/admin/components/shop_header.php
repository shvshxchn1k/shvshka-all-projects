<link rel="stylesheet" href="css/headerInAdmin.css">
<nav class="navi">
    <a href="?go=shop&sub=services" class="text-decoration-none">Услуги</a>
    <a href="?go=shop&sub=sets" class="text-decoration-none">Наборы</a>
    <a href="?go=shop&sub=subscription" class="text-decoration-none">Подписка</a>
    <a href="?go=shop&sub=other" class="text-decoration-none">Другое</a>
</nav>