<link rel="stylesheet" href="css/headerInAdmin.css">
<nav class="navi">
    <a href="?go=docs&sub=helpers" class="text-decoration-none">Хелперы</a>
    <a href="?go=docs&sub=moderators" class="text-decoration-none">Модераторы</a>
    <a href="?go=docs&sub=admins" class="text-decoration-none">Админы</a>
    <a href="?go=docs&sub=pr_manager" class="text-decoration-none">Пиар-менеджеры</a>
</nav>
