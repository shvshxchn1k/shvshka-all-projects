<link rel="stylesheet" href="css/sidebar.css">
<aside class="main-container d-flex">
    <div class="sidebar" id="side_nav">
        <div class="header-box px-2 pt-3 pb-4 d-flex justify-content-between">
            <h1 class="fs-4">
                <a href="index.php" class="bg-white text-dark rounded shadow px-2 me-2 text-decoration-none"><i class="fa-solid fa-image"></i> Smak Shine</a>
            </h1>
        </div>
        <ul class="list-unstyled px-2">
            <li>
                <?php echo '<a href="?go=profile&sub=' . $_SESSION['nickname'] . '" class="text-decoration-none px-3 py-2 d-block"><i class="fa-solid fa-user"></i> ' . $_SESSION['nickname'] . '</a>'; ?>
            </li>
            <li>
                <a href="?go=season_destroy" class="text-decoration-none px-3 py-2 d-block"><i class="fa-solid fa-right-to-bracket"></i> Выйти с сессии</a>
            </li>
        </ul>
        <hr class="h-color mx-2">
        <?php //if ($_SESSION['status'] == '1') { ?>
        <ul class="list-unstyled px-2">
            <li>
                <a href="?go=seasons" class="text-decoration-none px-3 py-2 d-block"><i class="fa-solid fa-tree"></i> Сезоны</a>
            </li>
            <li>
                <a href="?go=wiki" class="text-decoration-none px-3 py-2 d-block"><i class="fa-solid fa-book"></i> Вики</a>
            </li>
            <li>
                <a href="?go=shop&sub=services" class="text-decoration-none px-3 py-2 d-block"><i class="fa-solid fa-shop"></i> Магазин</a>
            </li>
        </ul>
        <hr class="h-color mx-2">
        <?php //} ?>
        <ul class="list-unstyled px-2">
            <li>
                <a href="?go=docs&sub=helpers" class="text-decoration-none px-3 py-2 d-block"><i class="fa-solid fa-file"></i> Документация</a>
            </li>
            <li>
                <a href=".." class="text-decoration-none px-3 py-2 d-block"><i class="fa-solid fa-house"></i> На главную</a>
            </li>

        </ul>
    </div>
</aside>
