<link rel="stylesheet" href="css/preloader.css">
<div id="preloader">
    <progress>Загрузка...</progress>
</div>

<script src="js/preloader.js"></script>

