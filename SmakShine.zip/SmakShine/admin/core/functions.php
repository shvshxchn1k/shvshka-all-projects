<?php
function dumpArray($array) {
    echo '<pre>';
    print_r($array);
    echo '</pre>';
}
function checkArray($array, $forbiddenCharacters) {
    foreach ($array as $key => $value) {
        $array[$key] = str_replace($forbiddenCharacters, '', $array[$key]);
        if ($value == '') {
            echo '<h1>Ошибка: вы ввели неправильно одно из полей</h1>';
            unset($array);
            break;
        }
    }
    return $array;
}
function saveInTable($table, $connect) {
    $fields_key = array_keys($_POST);
    $fields = [];
    foreach ($fields_key as $key => $field) {
        $fields[] = $field;
    }
    $fields = '(`id`,`' . implode('`,`', $fields) . '`)';

    $values = [];
    foreach ($_POST as $key => $value) {
        $value = trim($value);
        $values[] = $value;
    }
    $values = "(NULL,'" . implode("','", $values) . "')";

    $sql = "INSERT INTO `$table` {$fields} VALUES {$values}";
    $stmt = $connect->prepare($sql);
    $result = $stmt->execute();
    return $connect->lastInsertId();
}
function updateInTable($table, $connect, $id) {
    $fields_key = array_keys($_POST);
    $fields = [];
    foreach ($fields_key as $key => $field) {
        $fields[] = '`' . $field . '`';
    }

    $values = [];
    foreach ($_POST as $key => $value) {
        $value = trim($value);
        $values[] = "'" . $value . "'";
    }

    $fields_len = count($fields);
    $values_len = count($values);
    if ($fields_len == $values_len) {
        $update_values = [];
        for ($i = 0; $i != $fields_len; $i++) {
            $update_values[$i] = $fields[$i] . ' = ' . $values[$i];
        }
        $table = '`' . $table . '`';
        $sql = "UPDATE $table SET " . implode(",", $update_values) . " WHERE `id` = '$id';";
        $stmt = $connect->prepare($sql);
        $result = $stmt->execute();
    }
}
// Регулярные выражения
// Экранирование php, js