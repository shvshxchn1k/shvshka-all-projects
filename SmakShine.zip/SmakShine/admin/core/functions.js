function checkInput (selector, invalidKeys) {
    const input = document.querySelector(selector);

    input.addEventListener('keypress', function(e) {
        if (invalidKeys.test(e.key)) {
            e.preventDefault();
        }
    });


}

function checkInputEmpty () {
    const inputs = document.querySelectorAll('input');
    const btn = document.querySelector('button[type="submit"]');
    btn.style.display = 'none';

    inputs.forEach((input) => {
        input.addEventListener('input', (event) => {
            inputs.forEach((input) => {
                btn.style.display = 'block';
            });
        });
    });
}