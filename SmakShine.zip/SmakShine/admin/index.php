<?php
    include 'core/functions.php';
    include 'config/dbConnect.php';
    include 'config/session.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SmakShineAdmin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/3e299a4f17.js" crossorigin="anonymous"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="core/style.css">
    <script src="core/functions.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</head>
<body>
<?php
if (!isset($_SESSION['nickname'])) {
    if ($_GET['go'] != 'check') {
        echo '<meta http-equiv="refresh" content="1 url=?go=check" />';
    } else {
        $file = 'pages/check.php';
        include $file;
    }
} else {
    include 'components/sidebar.php';
    echo '<section class="page">';
    include 'components/preloader.php';
    if ($_GET['go']) {
//        if ($_SESSION['status'] != 1) {
//            $allowedPages = array('404', 'docs', 'main', 'profile', 'noAccess', 'season_destroy');
//            foreach ($allowedPages as $key => $value) {
//                if ($_GET['go'] == $value) {
//                    $page = $_GET['go'];
//                }
//            }
//        } else {
            $page = $_GET['go'];
//        }
        $file = 'pages/' . $page . '.php';
    } else {
        $file = 'pages/main.php';
    }
    if (!file_exists($file)) {
        $file = 'pages/404.php';
    }
    include $file;
    echo '</section>';
}
?>
</body>
</html>