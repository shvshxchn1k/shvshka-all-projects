<link rel="stylesheet" href="css/season.css">
<?php
if ($_GET['sub']) {
    $seasonNum = $_GET['sub'];
    $season = 'Сезон ' . $seasonNum;
    if ($connect == false){
        echo 'Ошибка, не подключился к бд';
    } else {
        $sql = "SELECT * FROM `seasons` WHERE `name` = '$season'";
        $result = $connect->query($sql);
        $row = $result->fetch_assoc();
        if ($row['status'] == 0) {
            include 'pages/404.php';
        } else {
            $seasonDescription = $row['description'];
            $sql = 'SELECT * FROM `seasons_images`';
            $result = mysqli_query($connect, $sql);
            if ($result == false) {
                echo 'Произошла ошибка при выполнении запроса';
            } else {
                $sql = "SELECT * FROM `seasons_images` WHERE `id_season` = '$season' AND  `status` = '1'";
                $result = $connect->query($sql);
                while ($row = mysqli_fetch_array($result)) {
                    $images[] = $row;
                }
                $imagesQuantity = count($images);
                $imagesPerRow = 3;
                ?>
                <header class="head">
                    <div class="seasonDescription">
                        <?php echo $seasonDescription; ?>
                    </div>
                </header>
                <section id="pictures">
                    <div class="imagesRow">
                        <?php
                        for ($i = 0; $i != $imagesQuantity; $i++) {
                            if ($i % $imagesPerRow == 0) {
                                if ($i != 0) {
                                    echo '</div>';
                                    echo '<div class="imagesRow">';
                                }
                            }
                            echo '<div class="block">';
                            echo '<a class="image-a" href="' . 'images/seasons/' . $images[$i]['image'] . '"><div class="image" style="background-image: url(' . 'images/seasons/' . $images[$i]['image'] . ')"></div></a>';
                            echo '<div class="description">' . $images[$i]['description'] . '</div>';
                            echo '</div>';
                        }
                        ?>
                </section>
                <?php
            }
        }
    }
} else {
    include 'pages/404.php';
}
?>

<!--join sql/php-->