<link rel="stylesheet" href="css/404.css">

<section class="error404">
    <div class="logo"><img src="images/404/smak_shine.png" alt="Лого"></div>
    <div class="text">
        <h1>Ошибка</h1>
        <h2>404...</h2>
        <h3>Похоже, что такой страницы не существует</h3>
        <a href="index.php"><button>На главную</button></a>
    </div>
</section>
