<link rel="stylesheet" href="css/webstats.css">
<h1 style="display: flex; justify-content: center;">Таблица все еще в разработке</h1>
<script type="module">
    import WebStats from "../webstats/WebStats-dist.js"
    window.addEventListener("load", () => {
        const stats = new WebStats ({
            host: "s19.joinserver.xyz:25584",
            tableParent: document.getElementById("webstats-tables"),
            updateInterval: 10_000,
            showSkins: true,
            displayCount: 100,
        });
    });
</script>
<main>
    <span>
        <input type="checkbox" name="hide-offline" id="hide-offline" class="webstats-option">
        <label for="hide-offline">Спрятать всех игроков, которые не в сети</label>
    </span>
    <span class="webstats-status">
        <span class="webstats-loading-indicator"><progress></progress></span>
        <span class="webstats-error-message"></span>
    </span>
    <div id="webstats-tables"></div>
</main>