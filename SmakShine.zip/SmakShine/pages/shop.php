<link rel="stylesheet" href="css/shop.css">
<header class="head">
    <a href="?go=shop&sub=services" class="text-decoration-none"><i class="fa-solid fa-cart-shopping"></i> Услуги</a>
    <a href="?go=shop&sub=sets" class="text-decoration-none"><i class="fa-solid fa-gift"></i> Наборы</a>
    <a href="?go=shop&sub=subscription" class="text-decoration-none"><i class="fa-solid fa-bell"></i> Подписка</a>
    <a href="?go=shop&sub=other" class="text-decoration-none"><i class="fa-solid fa-ghost"></i> Другое</a>
</header>
<hr class="hr">
<section class="body">
    <h1 style="display: flex; justify-content: center; align-items: center; text-align: center;">Покупки в магазине временно недоступны</h1>
    <div class="itemsRow">
        <?php
        if ($connect == false) {
            echo 'Ошибка, не подключился к бд';
        } else {
            if ($_GET['sub']) {
                $category = $_GET['sub'];
                if ($category == 'subscription') {
                    echo '<h1>Система подписки пока недоступна</h1>';
                } elseif ($category == 'sets') {
                    echo '<h1>Наборы временно недоступны</h1>';
                }
                $sql = "SELECT * FROM `shop` WHERE `category` = '$category' AND `status` = 1;";
                $result = $connect->query($sql);
                while ($row = mysqli_fetch_array($result)) {
                    $items[] = $row;
                }
                $items_len = count($items);
                $itemsPerRow = 3;
                for ($i = 0; $i != $items_len; $i++) {
                    if ($i % $itemsPerRow == 0) {
                        if ($i != 0) {
                            echo '</div>';
                            echo '<div class="itemsRow">';
                        }
                    }
                    echo '<div class="block">';
                    echo '<div class="image" style="background-image: url(images/shop/' . $items[$i]['image'] . ')"></div>';
                    echo '<div class="container-info">';
                    echo '<div class="name">' . $items[$i]['name'] . '</div>';
                    echo '<div class="description">' . $items[$i]['description'] . '</div>';
                    echo '</div>';
                    echo '<div class="price-container">';
                    echo '<div class="buy-button">В корзину</div>';
                    echo '<div class="price">' . $items[$i]['price'] . '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                include 'pages/404.php';
            }
        }
        ?>
</section>

