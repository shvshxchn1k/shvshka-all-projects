<link rel="stylesheet" href="css/main.css">
<div class="infinityScrollStrip" data-speed="0.1" data-direction="left"></div>
<div class="infinityScrollStrip" data-speed="0.1" data-direction="right"></div>
<section class="section-info">
    <div class="container-info">
        <div class="container-info-logo"></div>
        <div class="container-info-text">Smak Shine – Бесплатный ванильный Minecraft проект с элементами РП. Мы – уникальный проект, который является не только интереснейшим местом для знакомств и веселья, но проектом, судьбу которого вершат игроки.</div>
    </div>
</section>
<script src="js/main.js"></script>