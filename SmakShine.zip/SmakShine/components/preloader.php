<div id="preloader">
    <progress>Загрузка...</progress>
</div>

<script src="js/preloader.js"></script>

