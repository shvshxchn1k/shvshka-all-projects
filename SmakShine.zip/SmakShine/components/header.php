<link href="css/header.css" rel="stylesheet">
<nav class="navbar fixed-top navbar-expand-md navbar-dark">
    <div class="collapse navbar-collapse" id="navbarLeft">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item">
                <span><i class="fa-solid fa-tree"></i>&nbsp;Сезоны</span>
                <div class="dropdown">
                    <?php
                    $sql = "SELECT * FROM `seasons`";
                    $result = $connect->query($sql);
                    while ($row = mysqli_fetch_array($result)) {
                        $data[] = $row;
                    }
                    $data = array_reverse($data);
                    foreach ($data as $season => $value) {
                        if ($data[$season]['status'] == 1) {
                            $in_header = explode('.', $data[$season]['in_header']);
                            echo '<a href="?go=season&sub=' . $data[$season]['id'] . '"><i class="' . $in_header[0] . '"></i> ' . $in_header[1] . '</a>';
                        }
                    }
                    ?>
                </div>
            </li>
            <li class="nav-item">
                <a href="?go=shop&sub=services"><i class="fa-solid fa-shop"></i>&nbsp;Магазин</a>
            </li>
            <li class="nav-item">
                <a href="https://wiki.smakshine.com/" target="_blank"><i class="fa-solid fa-book"></i>&nbsp;Вики</a>
            </li>
        </ul>
    </div>
    <a href="../index.php" class="logoInNav"><img src="images/logo/smak_shine_round_round.png"></a>
    <div class="collapse navbar-collapse" id="navbarRight">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
                <span><i class="fa-solid fa-user"></i>&nbsp;Соц. Сети</span>
                <div class="dropdown">
                    <a href="https://discord.gg/W9DzB68tMB" target="_blank"><i class="fa-brands fa-discord"></i>&nbsp;Discord</a>
                    <a href="https://vk.com/smak_shine" target="_blank"><i class="fa-brands fa-vk"></i>&nbsp;VK</a>
                    <a href="https://t.me/Smak_Shine" target="_blank"><i class="fa-brands fa-telegram"></i>&nbsp;Telegram</a>
                    <a href="mailto:smakshine@gmail.com" target="_blank"><i class="fa-solid fa-envelope"></i>&nbsp;Почта</a>
                </div>
            </li>
            <li class="nav-item">
                <span><i class="fa-solid fa-globe"></i>&nbsp;Сервер</span>
                <div class="dropdown">
                    <a href="?go=webStats"><i class="fa-solid fa-charging-station"></i>&nbsp;WebStats</a>
                    <a href="https://map.smakshine.com/" target="_blank"><i class="fa-solid fa-map"></i>&nbsp;DynMap</a>
                </div>
            </li>
            <li class="nav-item">
                <?php if (isset($_SESSION['user']['nickname'])) { ?>
                    <a href="#"><i class="fa-solid fa-right-to-bracket"></i>&nbsp;Выйти</a>
                <?php } else { ?>
                    <a href="#"><i class="fa-solid fa-right-to-bracket"></i>&nbsp;Войти</a>
                <?php } ?>
            </li>
        </ul>
    </div>
    <button id="burgerButton" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarLeft, #navbarRight" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fa-solid fa-bars"></i>
    </button>
</nav>
