<link href="css/footer.css" rel="stylesheet">
<footer>
    <hr>
    <div class="footer-container">
        <div class="row">
            <div class="col">
                <h5><a href="https://discord.gg/W9DzB68tMB" target="_blank" class="text-decoration-none"><i class="fa-brands fa-discord"></i>&nbsp;Discord</a></h5>
            </div>
            <div class="col">
                <h5><a href="https://vk.com/smak_shine" target="_blank" class="text-decoration-none"><h5><i class="fa-brands fa-vk"></i>&nbsp;VK</a></h5>
            </div>
            <div class="col">
                <a href="../index.php" class="text-decoration-none"><h4><img class="logoInFooter" src="images/logo/smak_shine_round_round.png" alt="Logo"></h4></a>
            </div>
            <div class="col">
                <h5><a href="https://t.me/Smak_Shine" class="text-decoration-none" target="_blank"><i class="fa-brands fa-telegram"></i>&nbsp;Telegram</a></h5>
            </div>
            <div class="col">
                <h5><a href="mailto:smakshine@gmail.com" target="_blank" class="text-decoration-none"><i class="fa-solid fa-envelope"></i>&nbsp;Почта</a></h5>
            </div>
        </div>
    </div>
    <hr>
    <p><i class="fa-regular fa-copyright"></i> 2022-2025 Smak Shine, Inc</p>
</footer>