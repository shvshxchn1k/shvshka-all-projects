<!DOCTYPE html>
<html lang="en">
<head>
    <script src="admin/core/functions.js"></script>
    <meta charset="UTF-8">
    <title>Smak Shine – Ванильный РП Сервер</title>
    <link rel="shortcut icon" href="images/logo/smak_shine_round_round.png">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/3e299a4f17.js" crossorigin="anonymous"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="core/style.css">
    <?php
    include 'admin/core/functions.php';
    include 'admin/config/dbConnect.php';
    include 'admin/config/session.php';
    ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</head>
<body>
    <?php include 'components/header.php' ?>
    <main class="page">
        <?php
            include 'components/preloader.php';
            if (!isset($_GET['go'])) {
                $file = 'pages/main.php';
            } else {
                $page = $_GET['go'];
                $file = 'pages/' . $_GET['go'] . '.php';
            }
            if (!file_exists($file)) {
                $file = 'pages/404.php';
            }
            include $file;
        ?>
        <?php include 'components/footer.php'; ?>
        <div id="blocker"></div>
    </main>
    <script src="js/blocker.js"></script>
</body>
</html>